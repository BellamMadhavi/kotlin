package com.motivitylabs.bustrackingapp

// GlobalConfig.kt
object GlobalConfig {
//    var debugMode: Boolean = false // Remember to set this to false for production
var debugMode: Boolean = false // Remember to set this to false for production
}