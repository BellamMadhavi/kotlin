package com.motivitylabs.bustrackingapp.model.request

// In VerifyOtpRequest.kt
data class VerifyOtpRequest(
    val countryCode: String,
    val mobileNumber: String,
    var otp: String
)
