package com.motivitylabs.bustrackingapp.di

class AppModule {
}