package com.motivitylabs.bustrackingapp.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.motivitylabs.bustrackingapp.repository.UserRepository
import com.motivitylabs.bustrackingapp.util.ApiResult

class NotificationsViewModel (private val userRepository: UserRepository): ViewModel() {

    fun getNotifications(userId: String) = liveData {
        emit(ApiResult.Loading)
        val result = userRepository.getNotifications(userId)
        emit(result)
    }
}