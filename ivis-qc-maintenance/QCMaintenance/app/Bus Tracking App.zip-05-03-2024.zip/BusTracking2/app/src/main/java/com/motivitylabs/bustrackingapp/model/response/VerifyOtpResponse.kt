package com.motivitylabs.bustrackingapp.model.response

import com.google.gson.annotations.SerializedName

// In VerifyOtpResponse.kt
data class VerifyOtpResponse(
    @SerializedName("responseData") val responseData: UserData,
    @SerializedName("success") val success: Boolean,
    @SerializedName("errorMessages") val errorMessages: String
)

