package com.motivitylabs.bustrackingapp.network.response

import com.google.gson.annotations.SerializedName

data class SendOtpResponse(
    @SerializedName("responseData") val responseData: String,
    @SerializedName("success") val success: Boolean,
    @SerializedName("errorMessages") val errorMessages: String
)

// Assuming responseData could have specific fields in the future, start with an empty class
class ResponseData
