package com.motivitylabs.bustrackingapp.ui.fragment

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.motivitylabs.bustrackingapp.GlobalConfig
import com.motivitylabs.bustrackingapp.R
import com.motivitylabs.bustrackingapp.model.response.UserData
import com.motivitylabs.bustrackingapp.model.response.VerifyOtpResponse
import com.motivitylabs.bustrackingapp.network.RetrofitInstance
import com.motivitylabs.bustrackingapp.repository.UserRepository
import com.motivitylabs.bustrackingapp.ui.mainscreen.MainScreenFragment
import com.motivitylabs.bustrackingapp.ui.viewmodel.AuthSignInViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.AuthSignInViewModelFactory
import com.motivitylabs.bustrackingapp.ui.viewmodel.LoginViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.LoginViewModelFactory
import com.motivitylabs.bustrackingapp.ui.viewmodel.ProfileSharedViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.SharedViewModel
import com.motivitylabs.bustrackingapp.util.ApiResult
import retrofit2.HttpException

/**
 * A simple [Fragment] subclass.
 * Use the [DashboardFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class LoginFragment : Fragment() {

    lateinit var edt_mobilenum: EditText
    lateinit var btn_submit: LinearLayout
    lateinit var google_login_ll: LinearLayout
    lateinit var facebook_login_ll: LinearLayout

    private lateinit var googleSignInClient: GoogleSignInClient
    lateinit var auth: FirebaseAuth
    lateinit var email: String

    // Obtain a reference to the shared view model
    val sharedViewModel: ProfileSharedViewModel by activityViewModels()

    private val userRepository by lazy {
        UserRepository(RetrofitInstance.apiService) // Make sure to provide the actual ApiService instance
    }

    private val authSignInViewModel: AuthSignInViewModel by viewModels {
        AuthSignInViewModelFactory(userRepository)
    }


    private val loginViewModel: LoginViewModel by viewModels {
        // Create UserRepository instance with ApiService
        val userRepository = UserRepository(RetrofitInstance.apiService)
        // Pass UserRepository to the factory
        LoginViewModelFactory(userRepository)
    }

    private lateinit var viewModel: SharedViewModel

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view =  inflater.inflate(R.layout.fragment_login, container, false)

        edt_mobilenum = view.findViewById(R.id.edt_mobilenum)
        btn_submit = view.findViewById(R.id.btn_submit)


        viewModel = ViewModelProvider(requireActivity()).get(SharedViewModel::class.java)

        viewModel.mobileNumber.observe(viewLifecycleOwner, Observer { number ->
            // Use the mobile number here
            edt_mobilenum.setText(number)
        })


        google_login_ll = view.findViewById(R.id.google_login_ll)

        auth = Firebase.auth


        // Configure Google Sign In

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id)) // Replace with your Web Client ID
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(requireContext(), gso)


        google_login_ll.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {
                signIn()
            }
        })

        // This could be a user-entered number or a number you're programmatically setting
        val mobileNumber = edt_mobilenum.text.toString().trim()

        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        val editor = sharedPreferences.edit()
        editor.putString("mobile_number", mobileNumber)
        editor.apply()


        btn_submit.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {

                var mobileNumber = edt_mobilenum.text.toString().trim()

                if (GlobalConfig.debugMode) {
                    edt_mobilenum.setText("8790274613")
                    mobileNumber = "8790274613"
                }

                if (mobileNumber.isNotEmpty() && mobileNumber.length == 10) {
                    saveMobileNumber(mobileNumber)
                    val phoneNumber = "+91" +  mobileNumber // Example phone number, replace with actual input from user
                    if (GlobalConfig.debugMode) {
                        dummyAPICall()
                    }
                    else {
                        sendAPICall(phoneNumber)
                    }
                     //findNavController().navigate(R.id.action_LoginFragment_to_OtpverficationFragment)
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Please enter a valid 10-digit mobile number",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        })
        return view
    }

    private  fun dummyAPICall() {
        findNavController().navigate(R.id.action_LoginFragment_to_OtpverficationFragment)
//       findNavController().navigate(R.id.action_LoginFragment_to_DashboardFragment)

    }

    private fun signIn() {
        val signInIntent = googleSignInClient.signInIntent
        startActivityForResult(signInIntent, MainScreenFragment.RC_SIGN_IN)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // callbackManager?.onActivityResult(requestCode, resultCode, data)
        if (requestCode == MainScreenFragment.RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            val account: GoogleSignInAccount? = task.getResult(ApiException::class.java)

            try {
                // Google Sign In was successful, authenticate with Firebase
                val account = task.getResult(ApiException::class.java)!!
                Log.d(ContentValues.TAG, "firebaseAuthWithGoogle:" + account.id)
                firebaseAuthWithGoogle(account.idToken!!)
            } catch (e: ApiException) {
                // Google Sign In failed, update UI appropriately
                Log.w(ContentValues.TAG, "Google sign in failed", e)
            }
        }
    }

    fun firebaseAuthWithGoogle(idToken: String?) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(ContentValues.TAG, "signInWithCredential:success")
                    val user = auth.currentUser
                    updateUI(user)
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(ContentValues.TAG, "signInWithCredential:failure", task.exception)
                    updateUI(null)
                }
            }
    }

    private fun updateUI(user: FirebaseUser?) {
        if (user != null) {
            val email = user?.email.toString()

            authSignInViewModel.authSignIn(email)
                .observe(viewLifecycleOwner) { result ->
                    when (result) {
                        is ApiResult.Success<VerifyOtpResponse> -> {
                            Toast.makeText(
                                requireContext(),
                                "welcome " + result.data.responseData.fullName,
                                Toast.LENGTH_LONG
                            ).show()
                            sharedViewModel.setUserData(result.data.responseData)
                            findNavController().navigate(R.id.HomeFragment)
                        }

                        is ApiResult.Error -> {
                            if (result.exception is HttpException) {
                                when (result.exception.code()) {
                                    404 -> {
                                        val userData = UserData("", "", email, "",false)
                                        sharedViewModel.setUserData(userData)
                                        sharedViewModel.setEditButtonsVisibility(true)
                                        findNavController().navigate(
                                            R.id.HomeFragment,
                                            bundleOf("isNewUser" to true)
                                        )
                                    }
                                    200 -> {
                                        val message = "Email Verified Successfully"
                                        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                                        findNavController().navigate(R.id.Home)
                                        sharedViewModel.setEditButtonsVisibility(false)
                                    }
                                    else -> {
                                        // For other errors, show error message
                                        Toast.makeText(
                                            context,
                                            "Email Verification Failed, please try again... ",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            } else {
                                // Handle non-HttpException related errors
                                Toast.makeText(
                                    context,
                                    "An unexpected error occurred, please try again...",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                        is ApiResult.Loading -> {
                            // Show loading indicator
                        }
                    }
                }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                findNavController().navigate(R.id.MainScreenFragment)
            }
        })
    }

    private  fun sendAPICall(phoneNumber: String) {
        loginViewModel.sendOtp(phoneNumber).observe(viewLifecycleOwner) { result ->
            when (result) {
                is ApiResult.Success -> {
                    // OTP sent successfully, handle success scenario
                    findNavController().navigate(R.id.action_LoginFragment_to_OtpverficationFragment)
                }
                is ApiResult.Error -> {
                    if (result.exception is HttpException) {
                        when (result.exception.code()) {
                            500 -> {
                                val message = "Failed to send OTP, Please check your mobile number."
                                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                            }
                            200 -> {
                                val message = "OTP Sent Successfully"
                                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                }
                is ApiResult.Loading -> {

                }
            }
        }
    }

    private fun saveMobileNumber(mobileNumber: String) {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        val editor = sharedPreferences.edit()
        editor.putString("mobile_number", mobileNumber)
        editor.apply()
    }

}