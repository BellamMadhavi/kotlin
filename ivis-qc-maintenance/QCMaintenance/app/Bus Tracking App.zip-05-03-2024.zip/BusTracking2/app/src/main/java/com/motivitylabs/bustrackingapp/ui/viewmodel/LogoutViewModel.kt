package com.motivitylabs.bustrackingapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.motivitylabs.bustrackingapp.repository.UserRepository
import com.motivitylabs.bustrackingapp.util.ApiResult

class LogoutViewModel(private val userRepository: UserRepository) : ViewModel()  {
    fun logoutuser(toPhoneNumber: String) = liveData {
        emit(ApiResult.Loading)
        val result = userRepository.logoutUser(toPhoneNumber)
        emit(result)
    }
}