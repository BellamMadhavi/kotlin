package com.motivitylabs.bustrackingapp.ui.notifications

import android.app.Notification
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.motivitylabs.bustrackingapp.R
import com.motivitylabs.bustrackingapp.model.request.NotificationItem

class NotificationsAdapter(private val notifications: List<NotificationItem>) : RecyclerView.Adapter<NotificationsAdapter.ViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.notification_adapter, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val notificationItem = notifications[position]

        holder.busNumberTextView.text = notificationItem.busNumber
        holder.sourceTextView.text = notificationItem.source
        holder.destinationTextView.text = notificationItem.destination
        holder.seatsAvailableTextView.text = notificationItem.seatsAvailable
        holder.busNameTextView.text = notificationItem.busName
        holder.distanceTextView.text = notificationItem.distance
        holder.timeAwayTextView.text = notificationItem.timeAway
    }

    override fun getItemCount(): Int {
        return notifications.size
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {

        val busNumberTextView: TextView = itemView.findViewById(R.id.busNumberTextView)
        val sourceTextView: TextView = itemView.findViewById(R.id.sourceTextView)
        val destinationTextView: TextView = itemView.findViewById(R.id.destinationTextView)
        val seatsAvailableTextView: TextView = itemView.findViewById(R.id.seatsAvailableTextView)
        val busNameTextView: TextView = itemView.findViewById(R.id.busNameTextView)
        val distanceIconImageView: ImageView = itemView.findViewById(R.id.distanceIconImageView)
        val distanceTextView: TextView = itemView.findViewById(R.id.distanceTextView)
        val timeAwayTextView: TextView = itemView.findViewById(R.id.timeAwayTextView)
    }
}