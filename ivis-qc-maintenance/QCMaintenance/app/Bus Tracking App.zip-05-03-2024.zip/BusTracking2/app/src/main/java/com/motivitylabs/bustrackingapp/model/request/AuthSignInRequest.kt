package com.motivitylabs.bustrackingapp.model.request

data class AuthSignInRequest(
    val emailaddress: String
)
