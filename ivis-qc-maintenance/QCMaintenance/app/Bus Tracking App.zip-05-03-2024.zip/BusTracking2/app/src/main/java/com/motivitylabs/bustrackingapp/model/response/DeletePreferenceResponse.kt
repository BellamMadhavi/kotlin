package com.motivitylabs.bustrackingapp.model.response

import com.google.gson.annotations.SerializedName
import com.motivitylabs.bustrackingapp.ui.home.PreferenceFinal
data class DeletePreferenceResponse(
    val responseData: String,
    val success: Boolean,
    val errorMessages: String?
)