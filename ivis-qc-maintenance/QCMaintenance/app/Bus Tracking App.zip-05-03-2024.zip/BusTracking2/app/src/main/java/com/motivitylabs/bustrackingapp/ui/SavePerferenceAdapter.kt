package com.motivitylabs.bustrackingapp.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.motivitylabs.bustrackingapp.R
import com.motivitylabs.bustrackingapp.ui.home.Preference

class SavePreferenceAdapter(private val preferences: List<Preference>, private val listener: PreferenceItemListener) : RecyclerView.Adapter<SavePreferenceAdapter.ViewHolder>() {

    interface PreferenceItemListener {
        fun onEditClicked(preference: Preference)
        fun onDeleteClicked(preferenceId: String)
        fun onItemClicked(preferenceId: String)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.save_preference_adapter, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val preference = preferences[position]

        holder.preference_type.text = preference.name
        // from type text and image
        holder.txt_from.text = preference.fromType
        if (preference.fromType == "Home") {
            holder.fromIcon.setImageResource(R.drawable.home_icon) // Set home icon
        } else if (preference.fromType == "Work") {
            holder.fromIcon.setImageResource(R.drawable.work_icon) // Set office icon
        } else if (preference.fromType == "Travel") {
            holder.fromIcon.setImageResource(R.drawable.travel_icon) // Set office icon
        } else
            holder.fromIcon.setImageResource(R.drawable.school_icon)
        holder.address_txt_from.text = preference.fromLocation

        // to type text and image
        holder.txt_to.text = preference.toType
        if (preference.name == "Home") {
            holder.toIcon.setImageResource(R.drawable.home_icon) // Set home icon
        } else if (preference.name == "Work") {
            holder.toIcon.setImageResource(R.drawable.work_icon) // Set office icon
        } else if (preference.name == "Travel") {
            holder.toIcon.setImageResource(R.drawable.travel_icon) // Set office icon
        } else
            holder.toIcon.setImageResource(R.drawable.school_icon)

        holder.address_txt_to.text = preference.toLocation
        holder.start_time_txt.text = "Start: ${preference.startTime}"
        holder.return_time_txt.text = "Return: ${preference.returnTime}"
        if (preference.preferMetro) {
            holder.metro_selection_iv.setImageResource(R.drawable.right)
        } else {
            holder.metro_selection_iv.setImageResource(R.drawable.wrong)
        }
        holder.days_txt.text = preference.occurrenceType
        holder.customs_days.text = preference.days.toString()
        holder.edit_txt.visibility = View.VISIBLE
        holder.delete_txt.visibility = View.VISIBLE

        holder.edit_txt.setOnClickListener {
            listener.onEditClicked(preference)
        }

        holder.delete_txt.setOnClickListener {
            listener.onDeleteClicked(preference.preferenceId)
        }

        // Set up click listener for the whole item view
        holder.itemView.setOnClickListener {
            listener.onItemClicked(preference.preferenceId)
        }

        holder.show_more_image.setOnClickListener {
            if (holder.details_ll.visibility == View.GONE) {
                // Show the details and timings
                holder.details_ll.visibility = View.VISIBLE
                holder.timings_details_ll.visibility = View.VISIBLE
                holder.show_more_image.setImageResource(R.drawable.down_arrow)
            } else {
                // Hide the details and timings
                holder.details_ll.visibility = View.GONE
                holder.timings_details_ll.visibility = View.GONE
                holder.show_more_image.setImageResource(R.drawable.forward_arrow)
            }

        }

    }

    override fun getItemCount(): Int = preferences.size

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val txt_from: TextView = itemView.findViewById(R.id.txt_from)
        val fromIcon: ImageView = itemView.findViewById(R.id.fromIcon)
        val toIcon: ImageView = itemView.findViewById(R.id.toIcon)
        val address_txt_from: TextView = itemView.findViewById(R.id.address_txt_from)
        val txt_to: TextView = itemView.findViewById(R.id.txt_to)
        val address_txt_to: TextView = itemView.findViewById(R.id.address_txt_to)
        val start_time_txt: TextView = itemView.findViewById(R.id.start_time_txt)
        val return_time_txt: TextView = itemView.findViewById(R.id.return_time_txt)
        val days_txt: TextView = itemView.findViewById(R.id.days_txt)
        val customs_days: TextView = itemView.findViewById(R.id.customs_days)
        val edit_txt: TextView = itemView.findViewById(R.id.edit_txt)
        val delete_txt: TextView = itemView.findViewById(R.id.delete_txt)
        val metro_selection_iv: ImageView = itemView.findViewById(R.id.metro_selection)
        val show_more_image: ImageView = itemView.findViewById(R.id.show_more_image)
        val details_ll: LinearLayout = itemView.findViewById(R.id.details_ll)
        val timings_details_ll: LinearLayout = itemView.findViewById(R.id.timings_details_ll)
        val preference_type: TextView = itemView.findViewById(R.id.preference_type)
    }
}
