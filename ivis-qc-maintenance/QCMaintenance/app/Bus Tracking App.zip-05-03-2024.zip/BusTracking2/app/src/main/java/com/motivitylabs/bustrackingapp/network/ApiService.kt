package com.motivitylabs.bustrackingapp.network

// ApiService.kt
import com.motivitylabs.bustrackingapp.model.request.AddPreferenceRequest
import com.motivitylabs.bustrackingapp.model.request.RegisterRequest
import com.motivitylabs.bustrackingapp.model.request.UpdateProfileRequest
import com.motivitylabs.bustrackingapp.model.request.VerifyOtpRequest
import com.motivitylabs.bustrackingapp.model.response.DeletePreferenceResponse
import com.motivitylabs.bustrackingapp.model.response.FetchProfileResponse
import com.motivitylabs.bustrackingapp.model.response.NotificationResponse
import com.motivitylabs.bustrackingapp.model.response.PreferenceResponse
import com.motivitylabs.bustrackingapp.model.response.RegisterResponse
import com.motivitylabs.bustrackingapp.model.response.UpdateProfileResponse
import com.motivitylabs.bustrackingapp.model.response.VerifyOtpResponse
import com.motivitylabs.bustrackingapp.network.response.SendOtpResponse
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
        @POST("user/send-otp")
        suspend fun sendOtp(@Query("toPhoneNumber") toPhoneNumber: String): SendOtpResponse

        @POST("user/verify-otp")
        suspend fun verifyOtp(@Body request: VerifyOtpRequest): VerifyOtpResponse
    // Add more API calls here

        @POST("user/auth0/signin")
        suspend fun authsign(@Query("emailaddress") emailaddress: String): VerifyOtpResponse

        @POST("user/register")
        suspend fun registerUser(@Body request: RegisterRequest): RegisterResponse

        @POST("user/updateprofile")
        suspend fun updateProfile(@Body request: UpdateProfileRequest): UpdateProfileResponse

        @POST("preference")
        suspend fun addpreference(@Body preferencerequest: AddPreferenceRequest) : AddPreferenceRequest

        @PUT("preference")
        suspend fun editpreference(@Body preferencerequest: AddPreferenceRequest) : AddPreferenceRequest

        @GET("preference")
        suspend fun fetchPreferences(@Query("userId") userId: String): PreferenceResponse

        @DELETE("preference/{preferenceId}")
        suspend fun deletePreference(@Path("preferenceId") preferenceId: String): DeletePreferenceResponse

        @GET("/notifications/{userId}")
        suspend fun getNotifications(@Query("userId") userId: String?): NotificationResponse

        @GET("user/fetch")
        suspend fun fetchUserProfile(@Query("userId") userId: String): FetchProfileResponse

        @POST("user/signout")
        suspend fun logoutUser(@Query("contactNumber") phonenumber: String): SendOtpResponse
}

