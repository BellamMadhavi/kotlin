package com.motivitylabs.bustrackingapp.model.request

data class UpdateProfileRequest(
    val userID: String,
    val fullName: String,
    val email: String,
    val contactNumber: Long,
    val dailyCommuter: Boolean,
)