package com.motivitylabs.bustrackingapp.ui.home

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.motivitylabs.bustrackingapp.R
import com.motivitylabs.bustrackingapp.model.request.RegisterRequest
import com.motivitylabs.bustrackingapp.model.request.UpdateProfileRequest
import com.motivitylabs.bustrackingapp.network.RetrofitInstance
import com.motivitylabs.bustrackingapp.repository.UserRepository
import com.motivitylabs.bustrackingapp.ui.SavePreferenceAdapter
import com.motivitylabs.bustrackingapp.ui.viewmodel.PereferencesViewModelFactory
import com.motivitylabs.bustrackingapp.ui.viewmodel.PreferencesViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.ProfileSharedViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.RegisterViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.RegisterViewModelFactory
import com.motivitylabs.bustrackingapp.util.ApiResult
import com.motivitylabs.bustrackingapp.GlobalVariables
import com.motivitylabs.bustrackingapp.model.response.PreferenceResponse
import com.motivitylabs.bustrackingapp.model.response.RegisterResponse
import com.motivitylabs.bustrackingapp.model.response.UpdateProfileResponse
import com.motivitylabs.bustrackingapp.model.response.UserData
import com.motivitylabs.bustrackingapp.ui.viewmodel.LogoutViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.LogoutViewModelFactory
import java.io.Serializable

class HomeFragment : Fragment(), SavePreferenceAdapter.PreferenceItemListener {

    lateinit var saved_preference_ll: LinearLayout
    lateinit var txt_edit: TextView
    lateinit var edt_name: EditText
    lateinit var edt_gmail: EditText
    lateinit var edt_mobile: EditText
    lateinit var add_preference_ll: LinearLayout
    lateinit var user_details_ll: LinearLayout
    lateinit var btn_save: LinearLayout
    lateinit var txt_person_name: TextView
    lateinit var txt_gmail: TextView
    lateinit var txt_mobile: TextView
    lateinit var recyclerView: RecyclerView
    lateinit var radioGroup: RadioGroup

    private var isDailyCommuter: Boolean = true

    private var isEditMode = false
    lateinit var logout: LinearLayout

    // Obtain a reference to the shared view model
    val sharedViewModel: ProfileSharedViewModel by activityViewModels()

    private fun saveToPreferences(name: String, mobile: String, email: String, isDailyCommuter : Boolean) {
        val sharedPref = activity?.getSharedPreferences("UserDetails", Context.MODE_PRIVATE) ?: return
        with(sharedPref.edit()) {
            putString("name", name)
            putString("mobile", mobile)
            putString("email", email)
            putBoolean("isDailyCommuter", isDailyCommuter)


            apply()
        }
    }
    private fun loadFromPreferences() {
        val sharedPref = activity?.getSharedPreferences("UserDetails", Context.MODE_PRIVATE)
        sharedPref?.let {
            val name = it.getString("name", "")
            val mobile = it.getString("mobile", "")
            val email = it.getString("email", "")
            val isDailyCommuter = it.getBoolean("isDailyCommuter", false)

            // Update your UI here with the loaded details
            edt_name.setText(name)
            edt_gmail.setText(email)
            edt_mobile.setText(mobile)
            txt_person_name.text = name
            txt_gmail.text = email
            txt_mobile.text = mobile


            this.isDailyCommuter = isDailyCommuter
            // Also, update the checked state of radio buttons based on isDailyCommuter
            if (isDailyCommuter) {
                radioGroup.check(R.id.radio_daily_commuter)
            } else {
                radioGroup.check(R.id.radio_new_commuter)
            }
        }
    }
    private val preferenceViewModel : PreferencesViewModel by viewModels {
        // Create UserRepository instance with ApiService
        val userRepository = UserRepository(RetrofitInstance.apiService)
        // Pass UserRepository to the factory
        PereferencesViewModelFactory(userRepository)
    }

    private val registerViewModel: RegisterViewModel by viewModels {
        // Create UserRepository instance with ApiService
        val userRepository = UserRepository(RetrofitInstance.apiService)
        // Pass UserRepository to the factory
        RegisterViewModelFactory(userRepository)
    }

    private val logoutViewModel: LogoutViewModel by viewModels {
        // Create UserRepository instance with ApiService
        val userRepository = UserRepository(RetrofitInstance.apiService)
        // Pass UserRepository to the factory
        LogoutViewModelFactory(userRepository)
    }

    private fun setupRecyclerView2(preferencesListIP : List<PreferenceFinal>) {

        val preferencesList = preferencesListIP.map { preferenceFinal ->
            Preference(
                preferenceId = preferenceFinal.preferenceId,
                fromLocation = preferenceFinal.fromLocation,
                toLocation = preferenceFinal.toLocation,
                startTime = preferenceFinal.startTime,
                returnTime = preferenceFinal.returnTime,
                name = preferenceFinal.name,
                fromType = preferenceFinal.fromType,
                toType = preferenceFinal.toType,
                occurrenceType = preferenceFinal.occurrenceType,
                days = listOf(preferenceFinal.days.joinToString(",")),
                preferMetro = preferenceFinal.preferMetro,
                dailyCommuter = preferenceFinal.dailyCommuter,
                occupation = preferenceFinal.occupation
            )
        }
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = SavePreferenceAdapter(preferencesList, this)
        recyclerView.adapter?.notifyDataSetChanged()
    }

    override fun onItemClicked(preferenceId: String) {
        // Handle edit action
        // Perform deletion logic here, e.g., call ViewModel to delete from database or API
    }

    override fun onEditClicked(preference: Preference) {
        val bundle = Bundle().apply {
            putSerializable("preferenceDetails", preference as Serializable)
        }
        findNavController().navigate(R.id.AddPreferencesFragment, bundle)
    }


    override fun onDeleteClicked(preferenceId: String) {

        preferenceViewModel.deletePreference(preferenceId).observe(viewLifecycleOwner) { result ->
            when (result) {
                is ApiResult.Success<*> -> {
                    showAlertDialog("Success", "Preference deleted successfully") {
                        fetchPreferences() // Reload preferences after deletion
                    }
                }
                is ApiResult.Error -> {
                    val errorMessage = if (result.exception is retrofit2.HttpException && result.exception.code() == 404) {
                        result.exception.message ?: "Error occurred"
                    } else {
                        result.exception.message ?: "Error occurred"
                    }
                    showAlertDialog("Error", errorMessage)
                }
                is ApiResult.Loading -> {
                }
            }
        }
    }
    private fun showAlertDialog(title: String, message: String, onPositiveClicked: (() -> Unit)? = null) {
        AlertDialog.Builder(requireContext()).apply {
            setTitle(title)
            setMessage(message)
            setPositiveButton(android.R.string.ok) { dialog, _ ->
                onPositiveClicked?.invoke() // Invoke only if not null
                dialog.dismiss()
            }
            create()
            show()
        }
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_home, container, false)

        txt_edit = view.findViewById(R.id.txt_edit)
        edt_name = view.findViewById(R.id.edt_name)
        edt_gmail = view.findViewById(R.id.edt_gmail)
        edt_mobile = view.findViewById(R.id.edt_mobile)
        add_preference_ll = view.findViewById(R.id.add_preference_ll)
        btn_save = view.findViewById(R.id.btn_save)
        txt_person_name = view.findViewById(R.id.txt_person_name)
        txt_gmail = view.findViewById(R.id.txt_gmail)
        txt_mobile = view.findViewById(R.id.txt_mobile)
        recyclerView = view.findViewById(R.id.recyclerView)
        user_details_ll = view.findViewById(R.id.user_details_ll)
        saved_preference_ll = view.findViewById(R.id.saved_preferenceLayout)

        logout = view.findViewById(R.id.logout)


        radioGroup = view.findViewById(R.id.radioGroup)

        radioGroup.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.radio_daily_commuter -> {
                    isDailyCommuter = true
                }
                R.id.radio_new_commuter -> {
                    isDailyCommuter = false

                }
            }
        }

        val isNewUser = arguments?.getBoolean("isNewUser") ?: false
        if (isNewUser) {
            txt_edit.visibility = View.GONE
            saved_preference_ll.visibility = View.GONE
            user_details_ll.visibility = View.VISIBLE
            logout.visibility = View.GONE
        } else {
            user_details_ll.visibility = View.GONE
            txt_edit.visibility = View.VISIBLE
            saved_preference_ll.visibility = View.VISIBLE
            logout.visibility = View.VISIBLE

        }

        txt_edit.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {
                isEditMode = true
                txt_edit.visibility = View.GONE
                saved_preference_ll.visibility = View.GONE
                user_details_ll.visibility = View.VISIBLE
            }
        })

        add_preference_ll.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {
                findNavController().navigate(R.id.action_HomeFragment_to_AddPreferencesFragment)
            }
        })

        val userData = sharedViewModel.getUserData()
        updateProfileFields(userData)
        userData?.let {
                preferenceViewModel.fetchPreferences(it.userID).observe(viewLifecycleOwner) { result ->
                    when (result) {
                        is ApiResult.Success<*> -> {
                            val fetchedPreferences = result.data as PreferenceResponse // Cast to your preference type

                            if (fetchedPreferences.responseData.isNotEmpty()) {
                                // Preferences exist, setup RecyclerView and navigate to MainActivity
                                setupRecyclerView2(fetchedPreferences.responseData)
                                //navigateToMainActivity()
                            } else {
                                // No preferences exist, prompt the user to add at least one preference
                                if(isDailyCommuter == true)
                                    promptUserToAddPreference()
                            }
                            setupRecyclerView2(fetchedPreferences.responseData)
                        }
                        is ApiResult.Error -> {
                            if (result.exception is retrofit2.HttpException && result.exception.code() == 500) {
                                showAlertDialog("Error", "Failed to fetch preferences, internal server error")
                            } else {
                                showAlertDialog("Error", "Failed to fetch preferences")
                            }
                        }
                        is ApiResult.Loading -> {
                        }
                    }
                }
        }

        btn_save.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {
                txt_person_name.text = edt_name.text
                txt_gmail.text = edt_gmail.text
                txt_mobile.text = edt_mobile.text

              //  btn_save.
                val email = edt_gmail.text.toString()
                val fullname = edt_name.text.toString()
                val mobileString = edt_mobile.text.toString()

                if (!isValidEmail(email)) {
                    showErrorDialog("Invalid email format")
                    return
                }

                if (!isValidMobile(mobileString)) {
                    showErrorDialog("Mobile number must be 10 digits")
                    return
                }

                saveToPreferences(fullname, mobileString, email,isDailyCommuter)
                if (isEditMode) {
                    val mobile = mobileString.toLong() // Attempt to convert the mobile number to Long

                    val userData = sharedViewModel.getUserData()
                    updateProfileFields(userData)
                    userData?.let {
                        val updateProfileRequest = UpdateProfileRequest(it.userID,fullname, email, mobile,isDailyCommuter)
                        registerViewModel.updateProfile(updateProfileRequest).observe(viewLifecycleOwner) { result ->
                            // Handle registration result...
                            when (result) {
                                is ApiResult.Success<*> -> {
                                    // OTP sent successfully, handle success scenario
                                    Toast.makeText(context, "User profile details updated successfully", Toast.LENGTH_LONG).show()
                                    user_details_ll.visibility = View.GONE
                                    fetchPreferences()
                                    if(isDailyCommuter == true)
                                        findNavController().navigate(R.id.action_HomeFragment_to_AddPreferencesFragment)
                                    else {
                                        findNavController().navigate(R.id.action_HomeFragment_to_DashboardFragment)
                                    }
                                    // Reset the isEditMode flag
                                    isEditMode = false

                                    val userData = result.data as UpdateProfileResponse
                                    sharedViewModel.setUserData(userData.responseData)
                                }
                                is ApiResult.Error -> {
                                        Toast.makeText(context, "Update Profile, Internal server error. Code = " + result.exception.message, Toast.LENGTH_LONG).show()
                                }
                                is ApiResult.Loading -> {
                                    // Show loading indicator
                                }
                            }
                        }
                    }
                } else {
                    // If not in edit mode, proceed with registering the user
                    try {
                        val mobile = mobileString.toLong() // Attempt to convert the mobile number to Long

                        val registerUser = RegisterRequest(fullname, email, mobile, "+91",isDailyCommuter)
                        registerViewModel.registerUser(registerUser).observe(viewLifecycleOwner) { result ->

                                when (result) {
                                    is ApiResult.Success<*> -> {
                                        Toast.makeText(context, "Registered successfully", Toast.LENGTH_LONG).show()

                                        val userData = result.data as RegisterResponse
                                        sharedViewModel.setUserData(userData.responseData)

                                        if(isDailyCommuter == true)
                                            findNavController().navigate(R.id.action_HomeFragment_to_AddPreferencesFragment)
                                        else {
                                            findNavController().navigate(R.id.action_HomeFragment_to_DashboardFragment)
                                        }
                                    }
                                    is ApiResult.Error -> {
                                        if (result.exception is retrofit2.HttpException && result.exception.code() == 404) {
                                            // Navigate to the Home Fragment as this indicates a new user
                                            // For other errors, show error message
                                            Toast.makeText(context, "Register User response code = " + result.exception.message, Toast.LENGTH_LONG).show()
                                        } else {
                                            // For other errors, show error message
                                          //  Toast.makeText(context, "Register User response code = " +  result.exception.message, Toast.LENGTH_LONG).show()
                                        }

                                        if (result.exception is retrofit2.HttpException && result.exception.code() == 409) {
                                            if(isDailyCommuter == true)
                                                findNavController().navigate(R.id.action_HomeFragment_to_AddPreferencesFragment)
                                            else {
                                                findNavController().navigate(R.id.action_HomeFragment_to_DashboardFragment)
                                            }
                                        }


                                    }
                                    is ApiResult.Loading -> {

                                    }
                                }
                            }
                        }
                        catch (e: NumberFormatException) {
                            // Handle the case where the mobile number is not a valid Long
                            Toast.makeText(context, "Invalid mobile number format", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
        })

        logout.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {
                val userData = sharedViewModel.getUserData()
                val mobilenumber = userData?.contactNumber

                mobilenumber?.let { phoneNumber ->
                    logoutViewModel.logoutuser(phoneNumber).observe(viewLifecycleOwner) { result ->
                        when (result) {
                            is ApiResult.Success<*> -> {
                                val responseData = result.data
                                Log.d("API Response", responseData.toString())
                                findNavController().navigate(R.id.LoginFragment)
                            }

                            is ApiResult.Error -> {
                                val errorMessage = result.exception.message ?: "Error occurred"
                                Toast.makeText(context, errorMessage, Toast.LENGTH_SHORT).show()
                            }

                            is ApiResult.Loading -> {
                                // Handle loading state if needed
                            }
                        }
                    }
                }
            }
        })

        return view
    }

/*
    private fun fetchUserprofile() {
        val userData = sharedViewModel.getUserData()
        userData?.let { user ->
            preferenceViewModel.fetchUserProfile(user.userID).observe(viewLifecycleOwner) { result ->
                when (result) {
                    is ApiResult.Success<*> -> {
                       // val userProfile = result.data
                        userData?.let {
                            it.fullName?.takeIf { it.isNotBlank() }?.let { fullName ->
                                txt_person_name.text = fullName
                                edt_name.setText(fullName)
                            }

                            it.email?.takeIf { it.isNotBlank() }?.let { email ->
                                txt_gmail.text = email
                                edt_gmail.setText(email)
                            }

                            it.contactNumber?.takeIf { it.isNotBlank() }?.let { contactNumber ->
                                txt_mobile.text = contactNumber
                                edt_mobile.setText(contactNumber)
                            }
                        }
                    }
                    is ApiResult.Error -> {
                        val errorMessage = result.exception.message ?: "Error occurred"
                        Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_SHORT).show()

                        // Handle the error case
                    }
                    is ApiResult.Loading -> {
                        // Handle loading state
                    }
                }
            }
        }
    }
*/

    private fun fetchPreferences() {
        val userData = sharedViewModel.getUserData()
        updateProfileFields(userData)
        userData?.let { user ->
            preferenceViewModel.fetchPreferences(user.userID).observe(viewLifecycleOwner) { result ->
                when (result) {
                    is ApiResult.Success<*> -> {
                        val fetchedPreferences = result.data as PreferenceResponse
                        if (fetchedPreferences.responseData.isNotEmpty()) {
                            setupRecyclerView2(fetchedPreferences.responseData)
                        } else {
                            if(isDailyCommuter == true)
                                // No preferences exist, show dialogue
                                Toast.makeText(requireContext(), "Please add atleast one preference", Toast.LENGTH_LONG).show()
                        }
                    }
                    is ApiResult.Error -> {
                        // Handle error
                        val errorMessage = result.exception.message ?: "Error occurred"
                        showAlertDialog("Error", errorMessage)
                    }
                    is ApiResult.Loading -> {
                        // Optionally handle loading state
                    }
                }
            }
        }
    }


    private fun updateProfileFields(userData: UserData?) {
        userData?.let {
            it.fullName?.takeIf { it.isNotBlank() }?.let { fullName ->
                txt_person_name.text = fullName
                edt_name.setText(fullName)
            }

            it.email?.takeIf { it.isNotBlank() }?.let { email ->
                txt_gmail.text = email
                edt_gmail.setText(email)
            }

            it.contactNumber?.takeIf { it.isNotBlank() }?.let { contactNumber ->
                txt_mobile.text = contactNumber
                edt_mobile.setText(contactNumber)
            }

            if (isDailyCommuter) {
                radioGroup.check(R.id.radio_daily_commuter)
            } else {
                radioGroup.check(R.id.radio_new_commuter)
            }
        }
    }
    private fun isValidEmail(target: CharSequence): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(target).matches()
    }

    private fun isValidMobile(phone: String): Boolean {
        return phone.length == 10 && phone.all { it.isDigit() }
    }

    private fun showErrorDialog(message: String) {
        AlertDialog.Builder(requireContext())
            .setTitle("Input Error")
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    override fun onResume() {
        super.onResume()
        //loadFromPreferences()
    }


    private fun promptUserToAddPreference() {
        Toast.makeText(context, "Please add at least one preference, by clicking on Add Preferences.", Toast.LENGTH_LONG).show()
        // Optionally, navigate the user to the AddPreferenceFragment
        // findNavController().navigate(R.id.action_HomeFragment_to_AddPreferencesFragment)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        val radioDailyCommuter: RadioButton = view.findViewById(R.id.radio_daily_commuter)
        val radioNewCommuter: RadioButton = view.findViewById(R.id.radio_new_commuter)

        // Apply the color state list to the radio buttons
        val colorStateList = GlobalVariables.radioButtonColorStateList(requireContext())
        radioDailyCommuter.buttonTintList = colorStateList
        radioNewCommuter.buttonTintList = colorStateList

        // Directly access the user data from shared ViewModel
        val userData = sharedViewModel.getUserData()
        updateProfileFields(userData)
    }
}