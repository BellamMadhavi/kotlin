package com.motivitylabs.bustrackingapp.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.motivitylabs.bustrackingapp.model.request.AddPreferenceRequest
import com.motivitylabs.bustrackingapp.repository.UserRepository
import com.motivitylabs.bustrackingapp.util.ApiResult

class AddPereferenceViewModel(private val userRepository: UserRepository) :ViewModel() {

    fun addpreference(preferencerequest: AddPreferenceRequest) = liveData {
        emit(ApiResult.Loading)
        val result = userRepository.addpreference(preferencerequest)
        emit(result)
    }


    fun editpreference(preferencerequest: AddPreferenceRequest) = liveData {
        emit(ApiResult.Loading)
        val result = userRepository.editpreference(preferencerequest)
        emit(result)
    }
}