package com.motivitylabs.bustrackingapp.di

class ViewModelModule {
}