package com.motivitylabs.bustrackingapp.ui.dashboard

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.location.Location
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.widget.SearchView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.Dot
import com.google.android.gms.maps.model.Gap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PatternItem
import com.google.android.gms.maps.model.PolylineOptions
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.AutocompletePrediction
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.model.RectangularBounds
import com.google.android.libraries.places.api.model.TypeFilter
import com.google.android.libraries.places.api.net.FetchPlaceRequest
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest
import com.google.android.libraries.places.api.net.FindCurrentPlaceRequest
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.tabs.TabLayout
import com.google.maps.DirectionsApi
import com.google.maps.GeoApiContext
import com.motivitylabs.bustrackingapp.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.URL

import com.google.maps.android.PolyUtil
import com.google.maps.model.DirectionsResult
import com.google.maps.model.TravelMode
import com.motivitylabs.bustrackingapp.databinding.FragmentDashboardBinding
import com.motivitylabs.bustrackingapp.ui.dashboard.buses.Bus
import com.motivitylabs.bustrackingapp.ui.viewmodel.DashboardViewModel
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONException
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class DashboardFragment : Fragment(), OnMapReadyCallback, GoogleMap.OnMarkerClickListener, GoogleMap.OnMapClickListener {


    private var _binding: FragmentDashboardBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private lateinit var googleMap: GoogleMap
    private lateinit var  busDetailsCard: LinearLayout
    private val locationPermissionRequestCode = 1000

    private var sourceLocationLatLng: LatLng? = null
    private var destinationLocationLatLng: LatLng? = null
    private var currentLatitude: Double? = null
    private var currentLongitude: Double? = null
    private lateinit var tabsTransport:TabLayout
    private  lateinit var searchView: TextView
    private  lateinit var busStopSpinner: Spinner
    private  lateinit var busStopDistance: TextView

    val currentLocation = "$currentLatitude,$currentLongitude"
    // Assuming sourceLocationLatLng and destinationLocationLatLng are set
    val sourceLocation = "${sourceLocationLatLng?.latitude},${sourceLocationLatLng?.longitude}"
    private lateinit var busStopLocation: LatLng

    val apiKey = "AIzaSyDBOOKUbB5AjZGROTna4SGgfnF4_BgDX5M"

    // At the class level
    private var currentPredictions: List<AutocompletePrediction> = emptyList()

    val DOTTED_PATTERN = listOf(Dot(), Gap(20f))

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private  lateinit var srcString: String
    private  lateinit var dstString: String

    //    val buses = mutableListOf<Bus>()
    var buses = mutableListOf(
        Bus("127K", LatLng(17.4968, 78.3711),null,"TS05E101", "Madhapur", "Miyapur",  "full"),
        Bus("127K", LatLng(17.4968, 78.3711),null,"TS05E102", "Madhapur", "Miyapur",  "medium"),
        Bus("127K", LatLng(17.4968, 78.3711),null,"TS05E103", "Madhapur", "Miyapur",  "empty")
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val dashboardViewModel =
            ViewModelProvider(this).get(DashboardViewModel::class.java)

        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        val root: View = binding.root

// Get a reference to the card view and initially set it to be gone
        val sourceDestinationCardView = binding.sourceDestinationCardView
        sourceDestinationCardView.visibility = View.VISIBLE


        // Initialize the map fragment
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
            ?: SupportMapFragment.newInstance().also {
                childFragmentManager.beginTransaction().replace(R.id.map, it).commit()
            }
        mapFragment.getMapAsync(this)

        return root
    }


    private fun clearSearchFields() {
        val sourceAutoCompleteTextView = view?.findViewById<AutoCompleteTextView>(R.id.source)
        val destinationAutoCompleteTextView = view?.findViewById<AutoCompleteTextView>(R.id.destination)

        sourceAutoCompleteTextView?.setText("")
        destinationAutoCompleteTextView?.setText("")
    }

    val locations = arrayOf("Location 1", "Location 2", "Location 3", "Location 4")


    // Dummy function to set locations
    fun setLocationDetails() {
        // Dummy implementation for obtaining LatLng from a location name
        // In a real scenario, this could involve calling a geocoding API
        fun getLatLngFromLocationName(locationName: String): LatLng {
            // Dummy responses based on location names
            // Replace these with real geocoding results
            return when (locationName) {
                "uppal depo" -> LatLng(17.4021, 78.5591) // Example LatLng for Uppal Depot
                "secunderabad" -> LatLng(17.4411, 78.4983) // Example LatLng for Secunderabad
                "peerzadhiguda global indian international school" -> LatLng(17.4099, 78.5612) // Example LatLng for Peerzadiguda
                else -> LatLng(0.0, 0.0) // Default LatLng
            }
        }

        // Set source, destination, and current location using location names
        val sourceLocationName = "uppal depo"
        val destinationLocationName = "secunderabad"
        val currentLocationName = "peerzadhiguda global indian international school"

        // Obtain LatLng for each location
        val sourceLocationLatLng = getLatLngFromLocationName(sourceLocationName)
        val destinationLocationLatLng = getLatLngFromLocationName(destinationLocationName)
        val currentLocationLatLng = getLatLngFromLocationName(currentLocationName)

        currentLatitude = 17.4099
        currentLongitude = 78.5612

        val currentLocation = "$currentLatitude,$currentLongitude"
        val sourceLocation = "${sourceLocationLatLng?.latitude},${sourceLocationLatLng?.longitude}"
        val destination = "${destinationLocationLatLng?.latitude},${destinationLocationLatLng?.longitude}"

        fetchRouteAndInitializeBuses(sourceLocation, destination)

        addMarkersToMap(googleMap, currentLocation, sourceLocation, destination)


        sourceLocationLatLng?.let { destinationLocationLatLng?.let { it1 ->
            findBusStopsAlongRoute(it,
                it1
            )
        } }
        // Here you would add the logic to utilize these locations,
        // such as displaying them on a map, calculating distances, etc.
    }



    // Optionally, if you want to clear everything from the map, including markers, polylines, and other overlays
    fun clearEverythingFromMap() {
        googleMap.clear() // This removes all markers, polylines, and ground overlays from the map
    }

    // Function to reset location details
    fun resetLocationDetails() {
        // Assuming you have variables or properties to hold these values
        // Resetting source and destination locations to null or a default value
        val sourceLocationLatLng: LatLng? = null
        val destinationLocationLatLng: LatLng? = null

        // Resetting current location to a default value, could be null or zero depending on your requirement
        var currentLatitude: Double = 0.0
        var currentLongitude: Double = 0.0

        // If you are maintaining a string representation, reset these as well
        val currentLocation = "$currentLatitude,$currentLongitude"
        val sourceLocation = if (sourceLocationLatLng != null) "${sourceLocationLatLng.latitude},${sourceLocationLatLng.longitude}" else "0.0,0.0"
        val destination = if (destinationLocationLatLng != null) "${destinationLocationLatLng.latitude},${destinationLocationLatLng.longitude}" else "0.0,0.0"

        clearEverythingFromMap()
        // Log or print statements for debugging (optional)
        println("Locations reset: Source Location: $sourceLocation, Destination Location: $destination, Current Location: $currentLocation")
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tabsTransport = view.findViewById(R.id.tabs_transport)
        searchView = view.findViewById<TextView>(R.id.searchEditText)
        busStopDistance = view.findViewById<TextView>(R.id.busStopDistance)

        busDetailsCard = view.findViewById(R.id.busDetailsCard)
        val sourceDestinationCardView = binding.sourceDestinationCardView

        val searchIcon: Drawable? = ContextCompat.getDrawable(requireContext(), R.drawable.bg_search_input)
        searchIcon?.setBounds(0, 0, 10, 10) // Set the bounds to resize

        // Initially hide the sourceDestinationCardView
        sourceDestinationCardView.visibility = View.GONE

        busStopDistance.text = "1km"


        Places.initialize(requireContext(), this.apiKey)
        // Create a new Places client instance
        val placesClient = Places.createClient(requireContext())
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        // Initialize fused location client
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())


        sourceDestinationCardView.setOnClickListener {
            if (sourceDestinationCardView.visibility == View.GONE) {
                sourceDestinationCardView.visibility = View.VISIBLE
                searchView.visibility = View.GONE
            }
            if(sourceDestinationCardView.visibility == View.VISIBLE) {
                sourceDestinationCardView.visibility = View.GONE
                searchView.visibility = View.VISIBLE
            }
        }
        // Set the listener for when the SearchView is clicked (i.e., when the search icon is clicked)
        searchView.setOnClickListener {
            // clearEverythingFromMap()
            // Toggle the sourceDestinationCardView's visibility
            if (sourceDestinationCardView.visibility == View.GONE) {
                sourceDestinationCardView.visibility = View.VISIBLE
                searchView.visibility = View.GONE
                tabsTransport.visibility = View.GONE
            } else {
                sourceDestinationCardView.visibility = View.GONE
                searchView.visibility = View.VISIBLE
            }
        }

        // Create an ArrayAdapter using the string array and a default spinner layout
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, locations)

        // Apply the adapter to the source AutoCompleteTextView
        val sourceAutoCompleteTextView = view.findViewById<AutoCompleteTextView>(R.id.source)
        sourceAutoCompleteTextView.setAdapter(adapter)
       // sourceAutoCompleteTextView.threshold = 1  // Start showing suggestions after 1 character is typed

        // Apply the adapter to the destination AutoCompleteTextView
        val destinationAutoCompleteTextView = view.findViewById<AutoCompleteTextView>(R.id.destination)
        destinationAutoCompleteTextView.setAdapter(adapter)
        //destinationAutoCompleteTextView.threshold = 1  // Start showing suggestions after 1 character is typed


        setupPlacesAutoComplete(view, R.id.source)
        setupPlacesAutoComplete(view, R.id.destination)

         busStopSpinner = view.findViewById(R.id.busStopSpinner)

        // Define your dummy data
        val busStops = arrayOf("Madhapur Police Station", "Madhapur Hitech city")

        val busStopSpinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, busStops)
        busStopSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        busStopSpinner.adapter = busStopSpinnerAdapter
        busStopSpinner.visibility = View.GONE

        val tabLayout: TabLayout = view.findViewById(R.id.tabs_transport)
        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                // Change the color of the selected tab icon and text to teal_200
                tab?.icon?.setColorFilter(ContextCompat.getColor(requireContext(), R.color.teal_200), PorterDuff.Mode.SRC_IN)
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                // Revert the color of the unselected tab icon and text to the default
                tab?.icon?.clearColorFilter()
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
                // Optionally handle reselection if needed
            }
        })
        // Set the listener for when the close button ("X" button) of SearchView is clicked
/*        val closeButtonId = searchView.context.resources.getIdentifier("android:id/search_close_btn", null, null)
        val closeButton = searchView.findViewById<ImageView>(closeButtonId)
        closeButton.setOnClickListener {
            // Clear query text
            searchView.setQuery("", false)
            // Collapse the search view
            searchView.onActionViewCollapsed()
            // Hide the sourceDestinationCardView
            sourceDestinationCardView.visibility = View.GONE
        }
*/


        // Handle back press
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Check if you want to handle back press specifically for this fragment
                // For example, navigate to another fragment
                findNavController().navigate(R.id.action_DashboardFragment_to_HomeFragment)
            }
        })
        // Setup other listeners for query text changes and submission if needed
        // ...
    }

    private fun fetchAndDrawRoute(origin: String, destination: String, lineColor: Int, pattern: List<PatternItem>?) {
        val url = "https://maps.googleapis.com/maps/api/directions/json?origin=$origin&destination=$destination&key=$apiKey"

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val result = URL(url).readText()
                val jsonObject = JSONObject(result)
                val routes = jsonObject.getJSONArray("routes")
                if (routes.length() > 0) {
                    val route = routes.getJSONObject(0)
                    val polyline = route.getJSONObject("overview_polyline").getString("points")
                    val path = PolyUtil.decode(polyline)

                    withContext(Dispatchers.Main) {
                        drawPolyline(path, lineColor, pattern)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun drawPolyline(path: List<LatLng>, color: Int, pattern: List<PatternItem>?) {
        googleMap.addPolyline(
            PolylineOptions()
                .addAll(path)
                .color(color)
                .pattern(pattern) // Pass null for a solid line
        )
    }


    private fun setupPlacesAutoComplete(view: View, textViewId: Int) {
        val autocompleteTextView = view.findViewById<AutoCompleteTextView>(textViewId)
        val placesClient = Places.createClient(requireContext())

        autocompleteTextView.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s.toString()
                val request = FindAutocompletePredictionsRequest.builder()
                    .setQuery(query)
                    .build()

                placesClient.findAutocompletePredictions(request).addOnSuccessListener { response ->
                    currentPredictions = response.autocompletePredictions // Store predictions
                    val suggestions = response.autocompletePredictions.map { it.getFullText(null).toString() }
                    autocompleteTextView.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, suggestions))
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        autocompleteTextView.setOnItemClickListener { parent, _, position, _ ->
            val selectedPredictionId = currentPredictions[position].placeId // Use stored predictions

            val placeFields = listOf(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG)

            val fetchPlaceRequest = FetchPlaceRequest.builder(selectedPredictionId, placeFields).build()

            placesClient.fetchPlace(fetchPlaceRequest).addOnSuccessListener { fetchPlaceResponse ->
                val place = fetchPlaceResponse.place
                val latLng = place.latLng
                if (textViewId == R.id.source) {
                    // Assuming global variables to store LatLng
                    sourceLocationLatLng = latLng
                    srcString = place.name


                } else if (textViewId == R.id.destination) {
                    destinationLocationLatLng = latLng
                    val currentLocation = "$currentLatitude,$currentLongitude"
                    val sourceLocation = "${sourceLocationLatLng?.latitude},${sourceLocationLatLng?.longitude}"
                    val destination = "${destinationLocationLatLng?.latitude},${destinationLocationLatLng?.longitude}"

                    dstString = place.name
//                    fetchRouteAndInitializeBuses(sourceLocation, destination)
                    fetchRouteAndInitializeBusesStatic(srcString)

                    addMarkersToMap(googleMap, currentLocation, sourceLocation, destination)
                }
           }.addOnFailureListener { exception ->
                if (exception is ApiException) {
                    Log.e("Place not found", "Place not found: ${exception.statusCode}")
                }
            }
        }
    }

    fun addMarkersToMap(
        googleMap: GoogleMap,
        currentLocation: String,
        sourceLocation: String?,
        destinationLocation: String?
    ) {
        val currentLatLng = currentLocation.split(",").let { LatLng(it[0].toDouble(), it[1].toDouble()) }
        val sourceLatLng = sourceLocation?.split(",")?.let { LatLng(it[0].toDouble(), it[1].toDouble()) }
        val destinationLatLng = destinationLocation?.split(",")?.let { LatLng(it[0].toDouble(), it[1].toDouble()) }

        sourceLatLng?.let {
            val sourceMarker = googleMap.addMarker(
                MarkerOptions()
                    .position(it)
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.source_location)) // Replace with your source marker drawable
                    .title("Source")
            )
        }

        destinationLatLng?.let {
            val destinationMarker = googleMap.addMarker(
                MarkerOptions()
                    .position(it)
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.cur_location)) // Replace with your destination marker drawable
                    .title("Destination")
            )
        }

        currentLatLng?.let {
            val currentMarker = googleMap.addMarker(
                MarkerOptions()
                    .position(it)
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.source_location)) // Replace with your current marker drawable
                    .title("Current Location")
            )


        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun showToast(text: String) {
        Toast.makeText(context, text, Toast.LENGTH_SHORT).show()
    }
    override fun onMarkerClick(marker: Marker): Boolean {
        // Find the bus corresponding to the clicked marker
        val selectedBus = buses.find {
            bus ->
            "${bus.routeNo} - ${bus.busNumber}" == marker.title
        }

        selectedBus?.let { bus ->
            // Assuming you have a method to update the info card with the bus details
            updateInfoCard(bus)
        }

        return true // Return true to indicate that we have handled the event
    }


    private fun updateInfoCard(bus: Bus) {
        val detailsCard = view?.findViewById<LinearLayout>(R.id.busDetailsCard)

        detailsCard?.visibility = View.VISIBLE // Show the card

        // Update the card content
        view?.findViewById<TextView>(R.id.busNumber)?.text = bus.routeNo + "-" + bus.busNumber
        view?.findViewById<TextView>(R.id.busSource)?.text = bus.routeFrom
        view?.findViewById<TextView>(R.id.busDestination)?.text = bus.routeTo
        view?.findViewById<TextView>(R.id.busSeats)?.text = bus.occupancy // Example: "Seats Available"
        view?.findViewById<TextView>(R.id.busType)?.text = "Metro Express" // Example, you might need to adjust
        view?.findViewById<TextView>(R.id.busDistance)?.text = "1.5 km" // Example, calculate this if possible
        view?.findViewById<TextView>(R.id.busETA)?.text = "15min Away" // Example, calculate this if possible
    }

    // Global variables to store the random locations
    var randomLocations = mutableListOf<LatLng>()

    // Function to calculate bearing between two points
    fun calculateBearing(from: LatLng, to: LatLng): Double {
        val lat1 = Math.toRadians(from.latitude)
        val lat2 = Math.toRadians(to.latitude)
        val dLon = Math.toRadians(to.longitude - from.longitude)

        val y = sin(dLon) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        val bearing = atan2(y, x)

        return (Math.toDegrees(bearing) + 360) % 360
    }

    // Function to calculate a point given a start point, bearing, and distance
    fun calculateDestinationPoint(startPoint: LatLng, bearing: Double, distance: Double): LatLng {
        val radiusEarth = 6371.01 // Radius of the Earth in kilometers
        val distRatio = distance / radiusEarth
        val distRatioSine = sin(distRatio)
        val distRatioCosine = cos(distRatio)

        val startLatRad = Math.toRadians(startPoint.latitude)
        val startLonRad = Math.toRadians(startPoint.longitude)

        val startLatCos = cos(startLatRad)
        val startLatSin = sin(startLatRad)

        val bearingRad = Math.toRadians(bearing)

        val endLatRads = asin(startLatSin * distRatioCosine + startLatCos * distRatioSine * cos(bearingRad))
        val endLonRads = startLonRad + atan2(sin(bearingRad) * distRatioSine * startLatCos, distRatioCosine - startLatSin * sin(endLatRads))

        val endLat = Math.toDegrees(endLatRads)
        val endLon = Math.toDegrees(endLonRads)

        return LatLng(endLat, endLon)
    }

    // Function to find 3 random locations in the opposite direction and place markers
    fun findRandomLocationsAndPlaceMarkers(source: LatLng, destination: LatLng, googleMap: GoogleMap) {
        val oppositeBearing = (calculateBearing(source, destination) + 180) % 360

        randomLocations.clear()

        // Generate 3 random locations
        repeat(3) {
            val randomDistance = Random.nextDouble(1.0, 2.0) // Random distance between 1km and 2km
            val randomLocation = calculateDestinationPoint(source, oppositeBearing, randomDistance)
            randomLocations.add(randomLocation)

            activity?.runOnUiThread {
                // Place a marker for each location
                googleMap.addMarker(
                    MarkerOptions().position(randomLocation).title("Random Location $it")
                )
            }
        }
    }

    private fun getBusStopsAlongRoute(sourceLatLng: LatLng, destinationLatLng: LatLng) {
        // Set up your Google Maps API context
        val apiKey = apiKey
        val context = GeoApiContext.Builder().apiKey(apiKey).build()

        // Convert LatLng coordinates to string representation
        val sourceLocation = "${sourceLatLng.latitude},${sourceLatLng.longitude}"
        val destinationLocation = "${destinationLatLng.latitude},${destinationLatLng.longitude}"

        // Request directions from source to destination using transit mode
        val directionsResult: DirectionsResult = DirectionsApi.newRequest(context)
            .origin(sourceLocation)
            .destination(destinationLocation)
            .mode(TravelMode.TRANSIT)
            .await()

        // Parse the directions result to extract bus stops
        val busStops = mutableListOf<LatLng>()
        directionsResult.routes.forEach { route ->
            route.legs.forEach { leg ->
                leg.steps.forEach { step ->
                    if (step.travelMode == TravelMode.TRANSIT) {
                        // Check if the transit mode is a bus
                        if (step.transitDetails?.line?.vehicle?.type?.name == "BUS") {
                            // Extract the bus stop location
                            var busStopLocation1 = step.transitDetails?.departureStop?.location
                            if (busStopLocation1 != null) {

                                busStopLocation = LatLng(busStopLocation1.lat, busStopLocation1.lng)
                                // Convert LatLng coordinates to string representation
                                val busSourceLocation = "${busStopLocation.latitude},${busStopLocation.longitude}"

                                busStops.add(LatLng(busStopLocation1.lat, busStopLocation1.lng))

                                // Draw path from current location to source location
                                fetchAndDrawRoute(currentLocation, busSourceLocation, Color.GRAY, listOf(Dot(), Gap(20f))) // Dotted line for current to source
                                // Draw path from source location to destination
                                fetchAndDrawRoute(busSourceLocation, destinationLocation, Color.GREEN, null)


                                findRandomLocationsAndPlaceMarkers(sourceLocationLatLng!!, destinationLocationLatLng!!, googleMap )
                            }
                        }
                    }
                }
            }
        }

        // Add markers for the bus stops to the map
        busStops.forEach { busStop ->
            // Assuming you have a BitmapDescriptor for your custom icon
            val busStopIcon = BitmapDescriptorFactory.fromResource(R.drawable.bus_stop)

// Add marker with custom icon
// Add marker with custom icon
            activity?.runOnUiThread {
                googleMap.addMarker(
                    MarkerOptions()
                        .position(busStop)
                        .title("Bus Stop")
                        .icon(busStopIcon)
                )
            }

            // Draw dotted line from source to bus stop
            if (sourceLocationLatLng != null && busStopLocation != null) {
                val polylineOptions = PolylineOptions()
                    .add(sourceLocationLatLng)
                    .add(busStopLocation)
                    .color(Color.GRAY)
                    .pattern(listOf(Gap(20f), Dot()))
                activity?.runOnUiThread {
                    googleMap.addPolyline(polylineOptions)
                }
            }

        }
    }

    private fun fetchRoute(sourceLocation: LatLng, destinationLocation: LatLng): List<LatLng> {
        // Implement code to fetch route from source to destination
        // This can be done using Google Directions API or any other routing service
        // For simplicity, let's assume we already have a list of LatLng points representing the route
        return listOf(sourceLocation, LatLng(12.34, 56.78), LatLng(23.45, 67.89), destinationLocation)

    }

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1
        private val DESTINATION_LOCATION = LatLng(12.345, 67.890) // Replace with your destination coordinates
    }

    private fun findBusStopsAlongRoute(sourceLocation: LatLng, destinationLocation: LatLng) {
        GlobalScope.launch(Dispatchers.IO) {
            // Fetch route between source and destination
            val route = fetchRoute(sourceLocation, destinationLocation)
            // Retrieve bus stops along the route
            destinationLocationLatLng?.let { getBusStopsAlongRoute(sourceLocation, it) }
        }
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map


        // Set the map click listener
        googleMap.setOnMapClickListener(this)

        googleMap.setOnMarkerClickListener(this)

        checkLocationPermission()
        // Call the function
        // setLocationDetails()

        sourceLocationLatLng?.let { destinationLocationLatLng?.let { it1 ->
            findBusStopsAlongRoute(it,
                  it1
            )
        } }

//        addBusesNearCyberTowers()
//        fetchPathFromMadhapurToCyberTowers()
        // Now you can use googleMap to set up markers, move the camera, etc.
         // intialize 3 buses on map, simulate bus movement for every second.
    }

    override fun onMapClick(latLng: LatLng) {
        // Handle map click event here
        if (busDetailsCard.visibility == View.VISIBLE) {
            // If it's visible, set its visibility to "gone"
            busDetailsCard.visibility = View.GONE
        }
    }


    private fun checkLocationPermission() {
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                locationPermissionRequestCode
            )
            return
        }
        googleMap.isMyLocationEnabled = true
        showCurrentLocation()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == locationPermissionRequestCode && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            checkLocationPermission()
        }
    }

    private fun fetchRouteAndInitializeBuses(sourceLatLng:String, destinationLatLng:String) {
        CoroutineScope(Dispatchers.Main).launch {
            val route = getRouteFromSourceToDestination(sourceLatLng, destinationLatLng)
            if (route.isNotEmpty()) {

                sourceLocationLatLng?.let { destinationLocationLatLng?.let { it1 ->
                    findBusStopsAlongRoute(it,
                        it1
                    )
                } }


                initializeBuses(route)
                // startBusMovement(route)
                // startPeriodicApiSimulation()
                startSimulationWithRoute(sourceLatLng, destinationLatLng)
            } else {
                // Handle the case where the route could not be fetched
                Toast.makeText(context, "Failed to fetch the route", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun drawDottedRouteOnMap(map: GoogleMap, route: List<LatLng>) {
        val pattern: List<PatternItem> = listOf(Dot(), Gap(20f)) // Define a pattern for the dotted line
        val polylineOptions = PolylineOptions().apply {
            width(15f) // Set the width of the polyline
            color(Color.BLUE) // Set the color of the polyline
            addAll(route) // Add all the LatLng points to the polyline
            pattern(pattern) // Apply the pattern to the polyline
        }
        map.addPolyline(polylineOptions)
    }

    fun drawRouteOnMap(map: GoogleMap, route: List<LatLng>) {
            val polylineOptions = PolylineOptions().apply {
                width(15f) // Set the width of the polyline
                color(Color.BLUE) // Set the color of the polyline
                addAll(route) // Add all the LatLng points to the polyline
            }
            map.addPolyline(polylineOptions) // Add the polyline to the map
    }

    private fun addBusMarkersOnMapMadhapur(pathCoordinates: List<List<LatLng>>, map: GoogleMap) {
        pathCoordinates.forEachIndexed { index, route ->
            val busMarkerOptions = MarkerOptions().position(route.first()).title("Bus ${index + 1}")
            map.addMarker(busMarkerOptions)
        }

    }


    private fun generateRandomBuses(numBuses: Int, route: List<LatLng>): List<Bus> {
        val buses = mutableListOf<Bus>()

        val busRoutes = listOf(
            "Madhapur to Miyapur",
            "Miyapur to Madhapur",
            "Madhapur to Kondapur",
            "Kondapur to Miyapur",
            "Madhapur to Hitech City",
            "Hitech City to Miyapur"
        )

        val routeNumbers = mutableListOf<String>()
        for (i in 1..10) {
            val suffixes = listOf("224", "255", "312", "401", "533") // Example route number suffixes
            val randomSuffix = suffixes.random()
            routeNumbers.add("${i}H/$randomSuffix")
        }

        val occupancyOptions = listOf("full", "medium", "empty")


        repeat(numBuses) { index ->
            val randomRoute = busRoutes.random()
            val randomRouteNumber = routeNumbers.random()
            val randomOccupancy = occupancyOptions.random()
            val bus = Bus(
                routeNo = randomRouteNumber,
                busNumber = "TS-${(1000 + index)}",
                routeFrom = randomRoute.split(" to ")[0],
                routeTo = randomRoute.split(" to ")[1],
                position = route.first(), // Start from the first location of the route
                currentIndex = 0,
                occupancy = randomOccupancy
            )

            buses.add(bus)
        }

        return buses
    }
    private fun resizeBitmap(context: Context, iconResId: Int, scaleFactor: Float): Bitmap {
        val originalBitmap = BitmapFactory.decodeResource(context.resources, iconResId)
        val width = (originalBitmap.width * scaleFactor).toInt()
        val height = (originalBitmap.height * scaleFactor).toInt()
        return Bitmap.createScaledBitmap(originalBitmap, width, height, false)
    }

    private fun resizeBitmapDescriptor(context: Context, resourceId: Int, scaleFactor: Float): BitmapDescriptor {
        val originalBitmap = BitmapFactory.decodeResource(context.resources, resourceId)
        val width = (originalBitmap.width * scaleFactor).toInt()
        val height = (originalBitmap.height * scaleFactor).toInt()
        val scaledBitmap = Bitmap.createScaledBitmap(originalBitmap, width, height, false)
        return BitmapDescriptorFactory.fromBitmap(scaledBitmap)
    }

    private fun addBusMarkersOnMapWithDelay(pathCoordinates: List<List<LatLng>>, map: GoogleMap) {
        val handler = Handler()
        var currentIndices = IntArray(pathCoordinates.size) { 0 }

        val markers = mutableListOf<Marker>()
        /*val busIcons = arrayOf(
            // Replace R.drawable.bus1, R.drawable.bus2, R.drawable.bus3 with your actual drawable resources
            BitmapDescriptorFactory.fromResource(R.drawable.bus1),
            BitmapDescriptorFactory.fromResource(R.drawable.bus2),
            BitmapDescriptorFactory.fromResource(R.drawable.bus3)
        )*/
        val busIcons = arrayOf(
            resizeBitmapDescriptor(requireContext(), R.drawable.bus1, 0.5f),
            resizeBitmapDescriptor(requireContext(), R.drawable.bus2, 0.5f),
            resizeBitmapDescriptor(requireContext(), R.drawable.bus3, 0.5f)
        )

        val runnable = object : Runnable {
            override fun run() {

                // Clear existing markers
                markers.forEach { it.remove() }
                markers.clear()
                busStopSpinner.visibility = View.VISIBLE
                busStopDistance.visibility = View.VISIBLE

                // Add markers for the current locations of the buses
                pathCoordinates.forEachIndexed { index, route ->
                    val currentIndex = currentIndices[index]
                    val currentLocation = route[currentIndex]

                    val numBuses = 3 // Number of buses
                    val randomBuses = generateRandomBuses(numBuses, pathCoordinates.first())
                    buses = randomBuses.toList().toMutableList()
                    val idx = index % busIcons.size
                    val busMarkerOptions = MarkerOptions()
                        .position(currentLocation)
//                        .title("Bus ${index + 1}")
//                        .icon(busIcons[index]) // Set the icon for the bus
                        .icon(createCustomMarker(requireContext(), randomBuses[idx].routeNo, "15 min", randomBuses[idx].occupancy))
                        .title("${randomBuses[idx].routeNo} - ${randomBuses[idx].busNumber}")
                    val marker = map.addMarker(busMarkerOptions)
                    marker?.let { markers.add(it) }

                    // Move to the next location index for this route
                    currentIndices[index] = (currentIndex + 1) % route.size
                }

                // Schedule the next execution after 2 seconds
                handler.postDelayed(this, 2000)
            }
        }

        // Start the runnable
        handler.post(runnable)
    }

    // Assuming you have a GoogleMap object named 'map'
    private fun addBusStopMarker(map: GoogleMap, busStopLocation:LatLng) {
        val busStopMarkerOptions = MarkerOptions()
            .position(busStopLocation)
            .title("Bus Stop")
            .icon(BitmapDescriptorFactory.fromResource(R.drawable.bus_stop)) // Use your drawable resource

        map.addMarker(busStopMarkerOptions)
    }

    fun fetchRouteAndInitializeBusesStatic(source: String) {
        when {
            source.contains("Uppal", ignoreCase = true) -> {
                val route1 = getRouteUppalToSecunderabad()
                val route2 = getRouteGhatkesarToUppal()
                val route3 = getRouteHomeToUppal()
                // Initialize buses for route1 and route2
                // Remember to replace the following lines with actual implementations
                initializeBuses(route2)
                startSimulationWithRouteStatic(route2)
                drawRouteOnMap(googleMap, route1)
                drawDottedRouteOnMap(googleMap, route3)
            }
            source.contains("Madhapur", ignoreCase = true) -> {
                val route2 = getRouteJubileeHillsToMadhapur()

                CoroutineScope(Dispatchers.Main).launch {
                    val currentLocation = "$currentLatitude,$currentLongitude"
                    val destination = "${destinationLocationLatLng?.latitude},${destinationLocationLatLng?.longitude}"

                    val sourceLatLng = LatLng(17.440709, 78.392815)
                    val sourceLocation = "${sourceLatLng?.latitude},${sourceLatLng?.longitude}"

                    val route1 = getRouteFromSourceToDestination(sourceLocation, destination)
                    drawRouteOnMap(googleMap, route1)

                    val destinationLatLng = LatLng(17.4547628, 78.3769259)
                    val sourceString = "${sourceLatLng.latitude},${sourceLatLng.longitude}"
                    val dallasCenterCoordinates = LatLng(17.4327127,78.3759633)
                    val dallasCenterCoordinatesString = "${dallasCenterCoordinates.latitude},${dallasCenterCoordinates.longitude}"

                    val destinationString = "${destinationLatLng.latitude},${destinationLatLng.longitude}"
                    val route3 = getRouteFromSourceToDestination(dallasCenterCoordinatesString, sourceLocation)       // dallas center to madhapur

                    val pathCoordinates: List<List<LatLng>> = listOf(
                        listOf(
                            LatLng(17.438274, 78.399853),
                            LatLng(17.438570, 78.398715),
                            LatLng(17.438570, 78.397852),
                            LatLng(17.439327, 78.396334),
                            LatLng(17.440018, 78.394954),
                            LatLng(17.440380, 78.393885),
                            LatLng(17.440709, 78.392815)
                        ),
                        listOf(
                            LatLng(17.434259, 78.403475),
                            LatLng(17.435081, 78.402475),
                            LatLng(17.435674, 78.401716),
                            LatLng(17.436530, 78.400957),
                            LatLng(17.437720, 78.400097),
                            LatLng(17.438379, 78.399571),
                            LatLng(17.438617, 78.398714)
                        ),
                        listOf(
                            LatLng(17.429175, 78.412757),
                            LatLng(17.429887, 78.411873),
                            LatLng(17.429834, 78.410518),
                            LatLng(17.429808, 78.409717),
                            LatLng(17.430757, 78.408058),
                            LatLng(17.431654, 78.406980),
                            LatLng(17.433157, 78.405957)
                        )
                    )
                    addBusStopMarker(googleMap, LatLng(17.440709, 78.392815))
                    addBusMarkersOnMapWithDelay(pathCoordinates, googleMap)
                    drawDottedRouteOnMap(googleMap, route3)
                }
            }
            source.contains("Ameerpet", ignoreCase = true) -> {
                val route1 = getRouteAmeerpetToMiyapur()
                val route2 = getRouteBegumpetToAmeerpet()
                // Initialize buses for route1 and route2
                initializeBuses(route2)
                startSimulationWithRouteStatic(route2)
            }
        }
    }

    fun getRouteGhatkesarToUppal(): List<LatLng> {
        return listOf(
            LatLng(17.4474, 78.6725), // Ghatkesar Bus Stop
            LatLng(17.4467, 78.6698),
            LatLng(17.4460, 78.6671),
            LatLng(17.4453, 78.6644),
            LatLng(17.4446, 78.6617),
            LatLng(17.4439, 78.6590),
            LatLng(17.4432, 78.6563),
            LatLng(17.4425, 78.6536),
            LatLng(17.4418, 78.6509),
            LatLng(17.4411, 78.6482),
            LatLng(17.4404, 78.6455),
            LatLng(17.4397, 78.6428),
            LatLng(17.4390, 78.6401),
            LatLng(17.4383, 78.6374),
            LatLng(17.4376, 78.6347),
            LatLng(17.4369, 78.6320),
            LatLng(17.4362, 78.6293),
            LatLng(17.4355, 78.6266),
            LatLng(17.4348, 78.6239),
            LatLng(17.4341, 78.6212),
            LatLng(17.4334, 78.6185),
            LatLng(17.4327, 78.6158),
            LatLng(17.4320, 78.6131),
            LatLng(17.4313, 78.6104),
            LatLng(17.4306, 78.6077),
            LatLng(17.4299, 78.6050),
            LatLng(17.4292, 78.6023),
            LatLng(17.4285, 78.5996),
            LatLng(17.4278, 78.5969),
            LatLng(17.4271, 78.5942), // Approximation towards Uppal Depot
            LatLng(17.4061, 78.5594)  // Uppal Depot Bus Stop (adjusted final point for accuracy)
        )
    }

    fun getRouteHomeToUppal(): List<LatLng> {
        return listOf(
            LatLng(17.4099, 78.5612),  // Global Indian International School Uppal
            LatLng(17.4098, 78.5613),
            LatLng(17.4097, 78.5614),
            LatLng(17.4096, 78.5615),
            LatLng(17.4095, 78.5616),
            LatLng(17.4094, 78.5617),
            LatLng(17.4093, 78.5618),
            LatLng(17.4092, 78.5619),
            LatLng(17.4091, 78.5620),
            LatLng(17.4090, 78.5621),
            LatLng(17.4089, 78.5622),
            LatLng(17.4088, 78.5623),
            LatLng(17.4087, 78.5624),
            LatLng(17.4086, 78.5625),
            LatLng(17.4085, 78.5626),
            LatLng(17.4084, 78.5627),
            LatLng(17.4083, 78.5628),
            LatLng(17.4082, 78.5629),
            LatLng(17.4081, 78.5630),
            LatLng(17.4080, 78.5631),
            LatLng(17.4079, 78.5632),
            LatLng(17.4078, 78.5633),
            LatLng(17.4077, 78.5634),
            LatLng(17.4076, 78.5635),
            LatLng(17.4075, 78.5636),
            LatLng(17.4074, 78.5637),
            LatLng(17.4073, 78.5638),
            LatLng(17.4072, 78.5639),
            LatLng(17.4071, 78.5640),
            LatLng(17.4070, 78.5641),
            LatLng(17.4069, 78.5642),
            LatLng(17.4068, 78.5643),
            LatLng(17.4067, 78.5644),
        )
    }

    fun getRouteHomeToMadhapur(): List<LatLng> {
        return listOf(
            LatLng(17.4293917, 78.376114),
            LatLng(17.4310773694, 78.3762299645),
            LatLng(17.4327630388, 78.376345929),
            LatLng(17.4344487082, 78.3764618935),
            LatLng(17.4361343776, 78.376577858),
            LatLng(17.437820047, 78.3766938225),
            LatLng(17.4395057164, 78.376809787),
            LatLng(17.4411913858, 78.3769257515),
            LatLng(17.4428770552, 78.377041716),
            LatLng(17.4445627246, 78.3771576805),
            LatLng(17.446248394, 78.377273645),
            LatLng(17.4479340634, 78.3773896095),
            LatLng(17.4496197328, 78.377505574),
            LatLng(17.4513054022, 78.3776215385),
            LatLng(17.4529910716, 78.377737503),
            LatLng(17.454676741, 78.3778534675),
            LatLng(17.4563624104, 78.377969432),
            LatLng(17.4580480798, 78.3780853965),
            LatLng(17.4597337492, 78.378201361),
            LatLng(17.4614194186, 78.3783173255),
            LatLng(17.463105088, 78.37843329),
            LatLng(17.4647907574, 78.3785492545),
            LatLng(17.4664764268, 78.378665219),
            LatLng(17.4681620962, 78.3787811835),
            LatLng(17.4698477656, 78.378897148),
            LatLng(17.471533435, 78.3790131125),
            LatLng(17.4732191044, 78.379129077),
            LatLng(17.4749047738, 78.3792450415),
            LatLng(17.4765904432, 78.379361006)
        ) 
    }
            
    // Placeholder functions for route calculations
    fun getRouteUppalToSecunderabad(): List<LatLng> {
        return listOf(
            LatLng(17.4048, 78.5591),
            LatLng(17.40605172413793, 78.55700344827586),
            LatLng(17.407303448275865, 78.55490689655173),
            LatLng(17.408555172413795, 78.55281034482759),
            LatLng(17.409806896551725, 78.55071379310345),
            LatLng(17.411058620689655, 78.5486172413793),
            LatLng(17.41231034482759, 78.54652068965517),
            LatLng(17.41356206896552, 78.54442413793103),
            LatLng(17.41481379310345, 78.5423275862069),
            LatLng(17.41606551724138, 78.54023103448276),
            LatLng(17.417317241379312, 78.53813448275862),
            LatLng(17.41856896551724, 78.53603793103449),
            LatLng(17.41982068965517, 78.53394137931035),
            LatLng(17.421072413793105, 78.53184482758621),
            LatLng(17.422324137931035, 78.52974827586208),
            LatLng(17.423575862068965, 78.52765172413793),
            LatLng(17.424827586206895, 78.52555517241379),
            LatLng(17.42607931034483, 78.52345862068965),
            LatLng(17.42733103448276, 78.52136206896552),
            LatLng(17.42858275862069, 78.51926551724138),
            LatLng(17.429834482758622, 78.51716896551724),
            LatLng(17.431086206896552, 78.5150724137931),
            LatLng(17.432337931034482, 78.51297586206897),
            LatLng(17.433589655172412, 78.51087931034483),
            LatLng(17.434841379310345, 78.5087827586207),
            LatLng(17.436093103448275, 78.50668620689655),
            LatLng(17.437344827586205, 78.50458965517241),
            LatLng(17.438596551724135, 78.50249310344827),
            LatLng(17.43984827586207, 78.50039655172414),
            LatLng(17.4411, 78.4983)
        )
    }


    fun getRouteMadhapurToMiyapur(): List<LatLng> {
        return listOf(
            LatLng(17.4489, 78.3915),  // Madhapur
            LatLng(17.4490, 78.3916),
            LatLng(17.4491, 78.3917),
            LatLng(17.4492, 78.3918),
            LatLng(17.4493, 78.3919),
            LatLng(17.4494, 78.3920),
            LatLng(17.4495, 78.3921),
            LatLng(17.4496, 78.3922),
            LatLng(17.4497, 78.3923),
            LatLng(17.4498, 78.3924),
            LatLng(17.4499, 78.3925),
            LatLng(17.4500, 78.3926),
            LatLng(17.4501, 78.3927),
            LatLng(17.4502, 78.3928),
            LatLng(17.4503, 78.3929),
            LatLng(17.4504, 78.3930),
            LatLng(17.4505, 78.3931),
            LatLng(17.4506, 78.3932),
            LatLng(17.4507, 78.3933),
            LatLng(17.4508, 78.3934),
            LatLng(17.4509, 78.3935),
            LatLng(17.4510, 78.3936),
            LatLng(17.4511, 78.3937),
            LatLng(17.4512, 78.3938),
            LatLng(17.4513, 78.3939),
            LatLng(17.4514, 78.3940),
            LatLng(17.4515, 78.3941),
            LatLng(17.4516, 78.3942),
            LatLng(17.4517, 78.3943),
            LatLng(17.4518, 78.3944),  // Miyapur
        )
    }

    fun getRouteJubileeHillsToMadhapur(): List<LatLng> {
        return listOf(LatLng(17.434259, 78.403475),
            LatLng(17.434259, 78.403475),
            LatLng(17.435081, 78.402475),
            LatLng(17.435081, 78.402475),
            LatLng(17.435674, 78.401716),
            LatLng(17.435674, 78.401716),
            LatLng(17.436530, 78.400957),
            LatLng(17.436530, 78.400957),
            LatLng(17.437720, 78.400097),
            LatLng(17.437720, 78.400097),
            LatLng(17.438379, 78.399571),
            LatLng(17.438379, 78.399571),
            LatLng(17.438617, 78.398714),
            LatLng(17.438617, 78.398714))
    }

    fun getRouteAmeerpetToMiyapur(): List<LatLng> {
        // Implement route fetching logic here
        return listOf() // Placeholder return
    }

    fun getRouteBegumpetToAmeerpet(): List<LatLng> {
        // Implement route fetching logic here
        return listOf() // Placeholder return
    }


    suspend fun getRouteFromSourceToDestination(sourceLatLng:String, destinationLatLng:String): List<LatLng> = withContext(Dispatchers.IO) {
        try {
            val apiKey = "AIzaSyDBOOKUbB5AjZGROTna4SGgfnF4_BgDX5M" // Place your actual API key here

            val directionsUrl = "https://maps.googleapis.com/maps/api/directions/json" +
                    "?origin=$sourceLatLng&destination=$destinationLatLng" +
                    "&key=$apiKey"

            val result = URL(directionsUrl).readText()
            val jsonObject = JSONObject(result)
            val routes = jsonObject.getJSONArray("routes")
            if (routes.length() > 0) {
                val route = routes.getJSONObject(0)
                val overviewPolyline = route.getJSONObject("overview_polyline")
                val encodedPolyline = overviewPolyline.getString("points")
                PolyUtil.decode(encodedPolyline) // Decodes the polyline to a list of LatLng
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }


    private fun parseAndApplySimulatedJsonResponse(jsonResponse: String) {
        try {
            val jsonObject = JSONObject(jsonResponse)
            val busesArray = jsonObject.getJSONArray("buses")

            for (i in 0 until busesArray.length()) {
                val busObject = busesArray.getJSONObject(i)
                val routeNo = busObject.getString("RouteNo")
                val busNumber = busObject.getString("BusNumber")
                val lat = busObject.getDouble("Lat")
                val long = busObject.getDouble("Long")
                val occupancy = busObject.getString("Occupancy")

                // Find the matching bus in your list and update its details
                buses.find { it.busNumber == busNumber }?.apply {
                    position = LatLng(lat, long)
                    this.occupancy = occupancy
                    // Note: Marker update happens in the next step
                }
            }

            // After updating buses, reflect changes on the map
            updateMarkersBasedOnApiResponse()
        } catch (e: JSONException) {
            e.printStackTrace()
            // Handle parsing error
        }
    }

    private fun updateMarkersBasedOnApiResponse() {
        buses.forEach { bus ->
            val icon = when (bus.occupancy) {
                "full" -> BitmapDescriptorFactory.fromResource(R.drawable.bus3)
                "medium" -> BitmapDescriptorFactory.fromResource(R.drawable.bus2)
                "empty" -> BitmapDescriptorFactory.fromResource(R.drawable.bus1)
                else -> BitmapDescriptorFactory.defaultMarker() // Default case
            }

            // Update or create the marker for the bus
            // Update or create the marker for the bus
            if (bus.marker == null) {
                bus.marker = googleMap.addMarker(
                    MarkerOptions()
                        .position(bus.position)
                        .icon(createCustomMarker(requireContext(), bus.routeNo, "15 min", bus.occupancy))
                        .title("${bus.routeNo} - ${bus.busNumber}")
                        // Additional information could be set as a part of the snippet or another custom property.
                )
            } else {
                bus.marker?.apply {
                    position = bus.position
                    setIcon(createCustomMarker(requireContext(), bus.routeNo, "15 min", bus.occupancy))
                    title = "${bus.routeNo} - ${bus.busNumber}"
                   // Update the snippet or other property with the new info
                }
            }
        }
    }

    private fun startSimulationWithRoute(sourceLatLng:String, destinationLatLng:String) {
        CoroutineScope(Dispatchers.Main).launch {
            val route = getRouteFromSourceToDestination(sourceLatLng, destinationLatLng) // Fetch the route once
            while (isActive) {
                generateSimulatedJsonResponse(route) // Pass the route to the simulation
                delay(2000) // Update interval
            }
        }
    }



    private fun startSimulationWithRouteStatic(route: List<LatLng>) {
        CoroutineScope(Dispatchers.Main).launch {
            while (isActive) {
                generateSimulatedJsonResponse(route) // Pass the route to the simulation
                delay(2000) // Update interval
            }
        }
    }
    private fun createCustomMarker(context: Context, busNumber: String, eta: String, occupancy: String): BitmapDescriptor {
        // Determine the color based on occupancy
        val backgroundColor = when (occupancy) {
            "full" -> ContextCompat.getColor(context, R.color.full)
            "medium" -> ContextCompat.getColor(context, R.color.medium)
            "empty" -> ContextCompat.getColor(context, R.color.empty)
            else -> ContextCompat.getColor(context, R.color.unknown)
        }

        // Get bus icon
        val iconResId = when (occupancy) {
            "full" -> R.drawable.bus3
            "medium" -> R.drawable.bus2
            "empty" -> R.drawable.bus1
            else -> R.drawable.bus // Provide an appropriate default icon for unknown occupancy
        }
        var iconBitmap = BitmapFactory.decodeResource(context.resources, iconResId)
        val resizedBitmap = resizeBitmap(context, iconResId, 0.5f)
        iconBitmap = resizedBitmap
//        val iconBitmap =  resizeBitmapDescriptor(context, R.drawable.bus1, 0.5f),
        // Calculate bitmap dimensions for the text layout
        val text = "$busNumber, $eta"
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        textPaint.color = Color.WHITE
        // Set text size
        val textSizePx = context.resources.getDimensionPixelSize(R.dimen.custom_marker_text_size).toFloat()
        textPaint.textSize = textSizePx

        val textRect = Rect()
        textPaint.getTextBounds(text, 0, text.length, textRect)
        val textWidth = textRect.width()
        val textHeight = textRect.height()

        // Calculate total bitmap dimensions
        val iconSize = context.resources.getDimensionPixelSize(R.dimen.bus_icon_size)
        val padding = context.resources.getDimensionPixelSize(R.dimen.custom_marker_padding_vertical)
        val totalWidth = maxOf(iconSize, textWidth) + padding * 2 // Adjusted total width
        val totalHeight = iconSize + textHeight + padding * 3

        // Create a bitmap for the marker
        val bitmap = Bitmap.createBitmap(totalWidth, totalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Draw the background color for the text layout with rounded corners
        val backgroundRect = RectF(0f, 0f, textWidth.toFloat() + padding * 2, (textHeight + padding).toFloat()) // Adjusted background width
        val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        backgroundPaint.color = backgroundColor
        canvas.drawRoundRect(backgroundRect, (padding * 2).toFloat(), (padding * 2).toFloat(), backgroundPaint) // Adjusted corner radius

        // Draw the bus icon
        val iconLeft = (totalWidth - iconSize) / 2
        val iconTop = textHeight + padding * 2 // Adjusted top position for text layout
        canvas.drawBitmap(iconBitmap, iconLeft.toFloat(), iconTop.toFloat(), null)

        // Draw the text
        val textX = totalWidth / 2.toFloat() - (textWidth / 2) // Centering the text horizontally
        val additionalMargin = 2 * context.resources.displayMetrics.density

        val textY = (textHeight + padding * 2) / 2 - (textPaint.descent() + textPaint.ascent()) / 2 - padding + additionalMargin
        canvas.drawText(text, textX, textY, textPaint)

        return BitmapDescriptorFactory.fromBitmap(bitmap)
    }

    private fun generateSimulatedJsonResponse(route: List<LatLng>) {
        // Simulate updating bus positions along the route
        val busesJsonArray = buses.map { bus ->
            // Move to the next point along the route
            bus.currentIndex = (bus.currentIndex + 1) % route.size
            val nextPosition = route[bus.currentIndex]
            bus.position = nextPosition // Update the bus object for later

            // Keep occupancy simulation as before or adjust as needed
            val occupancy = when ((1..3).random()) {
                1 -> "full"
                2 -> "medium"
                else -> "empty"
            }
            bus.occupancy = occupancy // Update the bus object for later

            // Construct the JSON part for this bus
            """
            {
                "RouteNo": "${bus.routeNo}",
                "BusNumber": "${bus.busNumber}",
                "RouteFrom": "${bus.routeFrom}",
                "RouteTo": "${bus.routeTo}",
                "Lat": ${bus.position.latitude},
                "Long": ${bus.position.longitude},
                "Occupancy": "$occupancy"
            }
        """.trimIndent()
        }.joinToString(separator = ",", prefix = "[", postfix = "]")

        val jsonResponse = """{ "buses": $busesJsonArray }"""
        // Use this jsonResponse string as needed, for example, in simulating the API call
        parseAndApplySimulatedJsonResponse(jsonResponse)
    }


    private fun generateSimulatedJsonResponseMadhapur(route: List<LatLng>, currentLocation: LatLng) {
        // Simulate updating bus positions along the route
        val busesJsonArray = buses.map { bus ->
            // Move to the next point along the route
            bus.currentIndex = (bus.currentIndex + 1) % route.size
            val nextPosition = route[bus.currentIndex]
            bus.position = nextPosition // Update the bus object for later

            // Keep occupancy simulation as before or adjust as needed
            val occupancy = when ((1..3).random()) {
                1 -> "full"
                2 -> "medium"
                else -> "empty"
            }
            bus.occupancy = occupancy // Update the bus object for later

            // Construct the JSON part for this bus
            """
        {
            "RouteNo": "${bus.routeNo}",
            "BusNumber": "${bus.busNumber}",
            "RouteFrom": "${bus.routeFrom}",
            "RouteTo": "${bus.routeTo}",
            "CurrentLocation": {
                "Lat": ${currentLocation.latitude},
                "Long": ${currentLocation.longitude}
            },
            "NextLocation": {
                "Lat": ${nextPosition.latitude},
                "Long": ${nextPosition.longitude}
            },
            "Occupancy": "$occupancy"
        }
        """.trimIndent()
        }.joinToString(separator = ",")

        val jsonResponse = """{ "buses": [$busesJsonArray] }"""
        // Use this jsonResponse string as needed, for example, in simulating the API call
        parseAndApplySimulatedJsonResponse(jsonResponse)
    }
    private fun startSimulationWithRouteStaticMadhapur(routes: List<List<LatLng>>) {
        val delayInMillis = 2000L // Update interval

        CoroutineScope(Dispatchers.Main).launch {
            val numBuses = routes.size
            val currentBusLocations = IntArray(numBuses) { 0 }

            while (isActive) {
                for (i in 0 until numBuses) {
                    val route = routes[i]
                    val currentLocationIndex = currentBusLocations[i]
                    val currentLocation = route[currentLocationIndex]
                    generateSimulatedJsonResponseMadhapur(route, currentLocation) // Pass the current location of the bus
                    currentBusLocations[i] = (currentLocationIndex + 1) % route.size // Move to the next location on the route
                }
                delay(delayInMillis)
            }
        }
    }


    fun initializeBuses(route: List<LatLng>) {
        // Assume route is already fetched and not empty
        buses.forEachIndexed { index, bus ->
            // Assign a random position along the route to each bus
            val randomIndex = (route.indices).random()
            bus.position = route[randomIndex]
            bus.currentIndex = randomIndex

            // Update marker or create a new one if it doesn't exist
            val icon = when (bus.occupancy) {
                "full" -> BitmapDescriptorFactory.fromResource(R.drawable.bus3)
                "medium" -> BitmapDescriptorFactory.fromResource(R.drawable.bus2)
                "empty" -> BitmapDescriptorFactory.fromResource(R.drawable.bus1)
                else -> BitmapDescriptorFactory.defaultMarker()
            }

            if (bus.marker == null) {
                bus.marker = googleMap.addMarker(
                    MarkerOptions()
                        .position(bus.position)
                        .title("${bus.routeNo} - ${bus.busNumber}")
                        .icon(icon)
                )
            } else {
                bus.marker!!.position = bus.position
                bus.marker!!.setIcon(icon)
            }
        }
    }

    private fun showCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return
        }
        val fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())
        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            location?.let {
                currentLatitude = it.latitude
                currentLongitude = it.longitude
                val userLocation = LatLng(currentLatitude!!, currentLongitude!!)
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 12f))

            }
        }
    }
}