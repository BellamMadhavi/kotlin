package com.motivitylabs.bustrackingapp.repository

// BaseRepository.kt
import com.motivitylabs.bustrackingapp.util.ApiResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.HttpException

open class BaseRepository {

    protected suspend fun <T> apiCall(call: suspend () -> T): ApiResult<T> = withContext(Dispatchers.IO) {
        try {
            ApiResult.Success(call.invoke())
        } catch (e: Throwable) {
            ApiResult.Error(e)
        }
    }
}
