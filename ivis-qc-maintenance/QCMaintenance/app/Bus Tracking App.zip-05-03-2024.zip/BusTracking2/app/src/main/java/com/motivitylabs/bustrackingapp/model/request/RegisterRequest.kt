package com.motivitylabs.bustrackingapp.model.request

data class RegisterRequest(
    val fullName: String,
    val emailAddress: String,
    val contactNumber: Long,
    val countryCode: String,
    val dailyCommuter: Boolean,

)
