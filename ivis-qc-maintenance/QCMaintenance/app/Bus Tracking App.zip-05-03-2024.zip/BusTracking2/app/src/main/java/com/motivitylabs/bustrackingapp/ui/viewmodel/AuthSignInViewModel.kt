package com.motivitylabs.bustrackingapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.motivitylabs.bustrackingapp.model.request.AuthSignInRequest
import com.motivitylabs.bustrackingapp.model.request.VerifyOtpRequest
import com.motivitylabs.bustrackingapp.repository.UserRepository
import com.motivitylabs.bustrackingapp.util.ApiResult

class AuthSignInViewModel(private val userRepository: UserRepository) : ViewModel() {
    fun authSignIn(emailaddress: String) = liveData {
        emit(ApiResult.Loading)
        val result = userRepository.authSignIn(emailaddress)
        emit(result)
    }
}