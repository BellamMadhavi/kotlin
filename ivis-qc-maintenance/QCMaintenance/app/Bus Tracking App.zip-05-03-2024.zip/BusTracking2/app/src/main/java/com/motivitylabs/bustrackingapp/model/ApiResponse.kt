package com.motivitylabs.bustrackingapp.model

class ApiResponse {
}