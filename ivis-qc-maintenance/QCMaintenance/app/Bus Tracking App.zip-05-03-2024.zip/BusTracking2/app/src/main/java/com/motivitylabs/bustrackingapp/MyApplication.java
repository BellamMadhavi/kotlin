package com.motivitylabs.bustrackingapp;

import android.app.Application;

import com.google.android.libraries.places.api.Places;

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), "AIzaSyDBOOKUbB5AjZGROTna4SGgfnF4_BgDX5M");
        }
    }
}
