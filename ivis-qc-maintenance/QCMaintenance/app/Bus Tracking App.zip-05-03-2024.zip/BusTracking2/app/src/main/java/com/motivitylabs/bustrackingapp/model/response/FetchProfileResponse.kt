package com.motivitylabs.bustrackingapp.model.response

data class FetchProfileResponse(
    val responseData: List<UserData>,
    val success: Boolean,
    val errorMessages: String?
)
