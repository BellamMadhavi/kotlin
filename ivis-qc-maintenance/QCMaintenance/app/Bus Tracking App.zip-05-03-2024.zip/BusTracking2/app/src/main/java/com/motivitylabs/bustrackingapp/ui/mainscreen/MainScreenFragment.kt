package com.motivitylabs.bustrackingapp.ui.mainscreen

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.motivitylabs.bustrackingapp.R
import com.motivitylabs.bustrackingapp.model.request.AuthSignInRequest
import com.motivitylabs.bustrackingapp.model.request.VerifyOtpRequest
import com.motivitylabs.bustrackingapp.model.response.UserData
import com.motivitylabs.bustrackingapp.model.response.VerifyOtpResponse
import com.motivitylabs.bustrackingapp.network.RetrofitInstance
import com.motivitylabs.bustrackingapp.repository.UserRepository
import com.motivitylabs.bustrackingapp.ui.viewmodel.AuthSignInViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.AuthSignInViewModelFactory
import com.motivitylabs.bustrackingapp.ui.viewmodel.OtpVerificationViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.OtpVerificationViewModelFactory
import com.motivitylabs.bustrackingapp.ui.viewmodel.ProfileSharedViewModel
import com.motivitylabs.bustrackingapp.util.ApiResult
import retrofit2.HttpException


/**
 * A simple [Fragment] subclass.
 * Use the [MainScreenFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class MainScreenFragment : Fragment() {
    lateinit var continue_btn: LinearLayout
    lateinit var google_login_ll: LinearLayout
    lateinit var facebook_login_ll: LinearLayout

    private lateinit var googleSignInClient: GoogleSignInClient
    lateinit var auth: FirebaseAuth
    lateinit var email: String

    // Obtain a reference to the shared view model
    val sharedViewModel: ProfileSharedViewModel by activityViewModels()

    private val userRepository by lazy {
        UserRepository(RetrofitInstance.apiService) // Make sure to provide the actual ApiService instance
    }

    private val authSignInViewModel: AuthSignInViewModel by viewModels {
        AuthSignInViewModelFactory(userRepository)
    }


    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_main_screen, container, false)
        continue_btn = view.findViewById(R.id.continue_btn)

        facebook_login_ll = view.findViewById(R.id.facebook_login_ll)


        google_login_ll = view.findViewById(R.id.google_login_ll)

        auth = Firebase.auth


        // Configure Google Sign In

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id)) // Replace with your Web Client ID
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(requireContext(), gso)


        google_login_ll.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {
                signIn()
            }
        })

        facebook_login_ll.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {

            }
        })


        continue_btn.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {
                findNavController().navigate(R.id.action_MainScreenFragment_to_LoginFragment)

            }
        })
        return view
    }

    private fun signIn() {
        val signInIntent = googleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
       // callbackManager?.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            val account: GoogleSignInAccount? = task.getResult(ApiException::class.java)

            try {
                // Google Sign In was successful, authenticate with Firebase
                val account = task.getResult(ApiException::class.java)!!
                Log.d(ContentValues.TAG, "firebaseAuthWithGoogle:" + account.id)
                firebaseAuthWithGoogle(account.idToken!!)
            } catch (e: ApiException) {
                // Google Sign In failed, update UI appropriately
                Log.w(ContentValues.TAG, "Google sign in failed", e)
            }
        }
    }

    fun firebaseAuthWithGoogle(idToken: String?) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(ContentValues.TAG, "signInWithCredential:success")
                    val user = auth.currentUser
                    updateUI(user)
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(ContentValues.TAG, "signInWithCredential:failure", task.exception)
                    updateUI(null)
                }
            }
    }

    private fun updateUI(user: FirebaseUser?) {
        if (user != null) {
            val email = user?.email.toString()

            authSignInViewModel.authSignIn(email)
                .observe(viewLifecycleOwner) { result ->
                    when (result) {
                        is ApiResult.Success<VerifyOtpResponse> -> {
                            Toast.makeText(
                                requireContext(),
                                "welcome " + result.data.responseData.fullName,
                                Toast.LENGTH_LONG
                            ).show()
                            sharedViewModel.setUserData(result.data.responseData)
                            findNavController().navigate(R.id.HomeFragment)
                        }

                        is ApiResult.Error -> {
                            if (result.exception is HttpException) {
                                when (result.exception.code()) {
                                    404 -> {
                                        val userData = UserData("", "", email, "", false)
                                        sharedViewModel.setUserData(userData)
                                        sharedViewModel.setEditButtonsVisibility(true)
                                        findNavController().navigate(
                                            R.id.HomeFragment,
                                            bundleOf("isNewUser" to true)
                                        )
                                    }
                                    200 -> {
                                        val message = "Email Verified Successfully"
                                        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                                        findNavController().navigate(R.id.Home)
                                        sharedViewModel.setEditButtonsVisibility(false)
                                    }
                                    else -> {
                                        // For other errors, show error message
                                        Toast.makeText(
                                            context,
                                            "Email Verification Failed, please try again... ",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            } else {
                                // Handle non-HttpException related errors
                                Toast.makeText(
                                    context,
                                    "An unexpected error occurred, please try again...",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                        is ApiResult.Loading -> {
                            // Show loading indicator
                        }
                    }
                }
        }
    }

    companion object {
        const val RC_SIGN_IN = 1001
        const val EXTRA_NAME = "EXTRA_NAME"
    }

}