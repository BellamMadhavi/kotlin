package com.motivitylabs.bustrackingapp.ui.dashboard.buses

import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker

data class Bus(
    val routeNo: String,
    var position: LatLng,
    var marker: Marker? = null, // Holds the marker for this bus
    val busNumber: String = "",
    val routeFrom: String= "",
    val routeTo: String = "",
    var occupancy: String = "",
    var currentIndex: Int = 0
)
