package com.motivitylabs.bustrackingapp.ui.notifications

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.motivitylabs.bustrackingapp.R
import com.motivitylabs.bustrackingapp.model.request.NotificationItem
import com.motivitylabs.bustrackingapp.network.RetrofitInstance
import com.motivitylabs.bustrackingapp.repository.UserRepository
import com.motivitylabs.bustrackingapp.ui.viewmodel.NotificationsViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.NotificationsViewModelFactory
import com.motivitylabs.bustrackingapp.ui.viewmodel.ProfileSharedViewModel
import com.motivitylabs.bustrackingapp.util.ApiResult

class NotificationsFragment : Fragment() {

    lateinit var recyclerView: RecyclerView

   lateinit var notificationAdapter: NotificationsAdapter


    val sharedViewModel: ProfileSharedViewModel by activityViewModels()

    private val notificationsViewModel : NotificationsViewModel by viewModels {
        // Create UserRepository instance with ApiService
        val userRepository = UserRepository(RetrofitInstance.apiService)
        // Pass UserRepository to the factory
        NotificationsViewModelFactory(userRepository)
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view =  inflater.inflate(R.layout.fragment_notifications, container, false)

        recyclerView = view.findViewById(R.id.notifications_recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        val userData = sharedViewModel.getUserData()
        userData?.let {
            notificationsViewModel.getNotifications(it.userID)
                .observe(viewLifecycleOwner) { result ->
                    when (result) {
                        is ApiResult.Success<*> -> {
                            val notifications = result.data as List<NotificationItem>
                            // Initialize adapter with notifications
                            notificationAdapter = NotificationsAdapter(notifications)
                            // Set adapter to RecyclerView
                            recyclerView.adapter = notificationAdapter
                        }
                        is ApiResult.Error -> {

                            if (result.exception is retrofit2.HttpException && result.exception.code() == 404) {
                                // Navigate to the Home Fragment as this indicates a new user
                                // For other errors, show error message
//                                Toast.makeText(context, result.exception.message, Toast.LENGTH_LONG).show()
                            } else {
                                // For other errors, show error message
//                                Toast.makeText(context, result.exception.message, Toast.LENGTH_LONG).show()
                            }

                            val dummyNotifications = getDummyNotifications()
                            notificationAdapter = NotificationsAdapter(dummyNotifications)
                            recyclerView.adapter = notificationAdapter
                        }
                        is ApiResult.Loading -> {
                            // Show loading indicator
                        }
                    }
                }
        }

        return view
    }


    private fun getDummyNotifications(): List<NotificationItem> {
        return listOf(
            NotificationItem("80D - TS52BH6587", "Jubilee Hills", "Madhapur", "Seats Available", "Metro Express", "1.5 km", "15min Away"),
            NotificationItem("Another Bus", "Another Source", "Another Destination", "Seats Available", "Another Bus Name", "2.0 km", "20min Away"),
        )
    }

}