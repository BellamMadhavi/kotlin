package com.motivitylabs.bustrackingapp.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.google.gson.Gson
import com.motivitylabs.bustrackingapp.model.response.PreferenceResponse
import com.motivitylabs.bustrackingapp.repository.UserRepository
import com.motivitylabs.bustrackingapp.ui.home.PreferenceFinal
import com.motivitylabs.bustrackingapp.util.ApiResult

class PreferencesViewModel(private val userRepository: UserRepository) : ViewModel()  {
    private val _preferences = MutableLiveData<List<PreferenceFinal>>()
    val preferences: LiveData<List<PreferenceFinal>> = _preferences

    fun fetchPreferences(userId: String) = liveData {
        emit(ApiResult.Loading)
        val result = userRepository.fetchPreferences(userId)
        emit(result)
    }

    // LiveData to observe deletion status
    private val _deleteStatus = MutableLiveData<Boolean>()
    val deleteStatus: LiveData<Boolean> get() = _deleteStatus
    fun deletePreference(preferenceId: String) = liveData {

    emit(ApiResult.Loading)
        val result = userRepository.deletePreference(preferenceId)
        emit(result)
    }

    fun fetchUserProfile(userId: String) = liveData {
        emit(ApiResult.Loading)
        val result = userRepository.fetchUserProfile(userId)
        emit(result)
    }

}