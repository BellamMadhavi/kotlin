package com.motivitylabs.bustrackingapp.ui.dashboard.buses

data class BusStop(val name: String, val latitude: Double, val longitude: Double)
