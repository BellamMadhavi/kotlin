package com.motivitylabs.bustrackingapp.model.request

data class NotificationItem(
    val busNumber: String,
    val source: String,
    val destination: String,
    val seatsAvailable: String,
    val busName: String,
    val distance: String,
    val timeAway: String
)