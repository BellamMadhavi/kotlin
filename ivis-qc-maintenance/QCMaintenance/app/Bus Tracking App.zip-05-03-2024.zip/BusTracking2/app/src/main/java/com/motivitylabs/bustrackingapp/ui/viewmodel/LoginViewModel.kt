package com.motivitylabs.bustrackingapp.ui.viewmodel

// UserViewModel.kt
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.motivitylabs.bustrackingapp.repository.UserRepository
import com.motivitylabs.bustrackingapp.util.ApiResult

class LoginViewModel(private val userRepository: UserRepository) : ViewModel() {

    fun sendOtp(toPhoneNumber: String) = liveData {
        emit(ApiResult.Loading)
        val result = userRepository.sendOtp(toPhoneNumber)
        emit(result)
    }


    // Add more functions to handle other API calls similarly
}
