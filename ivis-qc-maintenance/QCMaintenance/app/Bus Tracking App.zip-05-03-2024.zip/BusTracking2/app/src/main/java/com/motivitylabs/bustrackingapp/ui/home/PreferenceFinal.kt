package com.motivitylabs.bustrackingapp.ui.home

data class PreferenceFinal(
    val preferenceId: String,
    val fromLocation: String,
    val toLocation: String,
    val startTime: String,
    val returnTime: String,
    val name: String,
    val fromType: String,
    val toType: String,
    val occurrenceType: String,
    val days: List<String>,
    val preferMetro: Boolean,
    val dailyCommuter: Boolean,
    val occupation: String
)