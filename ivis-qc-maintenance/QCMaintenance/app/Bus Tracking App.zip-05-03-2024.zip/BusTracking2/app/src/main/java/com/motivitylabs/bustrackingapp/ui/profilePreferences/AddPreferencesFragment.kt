package com.motivitylabs.bustrackingapp.ui.profilePreferences

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.style.StyleSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CalendarView
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.view.children
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.android.volley.VolleyLog.TAG
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.AutocompleteActivity
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.motivitylabs.bustrackingapp.GlobalVariables
import com.motivitylabs.bustrackingapp.R
import com.motivitylabs.bustrackingapp.model.request.AddPreferenceRequest
import com.motivitylabs.bustrackingapp.model.request.RegisterRequest
import com.motivitylabs.bustrackingapp.network.RetrofitInstance
import com.motivitylabs.bustrackingapp.repository.UserRepository
import com.motivitylabs.bustrackingapp.ui.home.Preference
import com.motivitylabs.bustrackingapp.ui.viewmodel.AddPereferenceViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.AddPereferenceViewModelFactory
import com.motivitylabs.bustrackingapp.ui.viewmodel.ProfileSharedViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.RegisterViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.RegisterViewModelFactory
import com.motivitylabs.bustrackingapp.util.ApiResult
import org.w3c.dom.Text

/**
 * A simple [Fragment] subclass.
 * Use the [AddPreferencesFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class AddPreferencesFragment : Fragment()/*, View.OnClickListener*/ {

    lateinit var preference: Preference
    lateinit var days_picker_layout: LinearLayout
    lateinit var start_time_ll: LinearLayout
    lateinit var end_time_ll: LinearLayout
    lateinit var timePicker_startTime: TimePicker
    lateinit var timePicker_EndTime: TimePicker
    lateinit var calendar_imgview: ImageView
    lateinit var calendarView: CalendarView
    lateinit var startTime_txtview: TextView
    lateinit var EndTime_txtview: TextView
    lateinit var custom_calendar_txt: TextView
    lateinit var edt_from: TextView
    lateinit var iv_from: ImageView
    lateinit var edt_to: TextView
    lateinit var occupation_name: EditText
    lateinit var iv_to: ImageView

    lateinit var buttonSunday: TextView
    lateinit var buttonMonday: TextView
    lateinit var buttonTuesday: TextView
    lateinit var buttonWednesday: TextView
    lateinit var buttonThursday: TextView
    lateinit var buttonFriday: TextView
    lateinit var buttonSaturday: TextView

    private var isDailyCommuter: Boolean = false

    lateinit var calendar_days: LinearLayout
    lateinit var from_type_ll: LinearLayout

    lateinit var tvDaily: TextView

    lateinit var switchButton: Switch

    private var Prefer_Metro: Boolean = false

    lateinit var btn_save: LinearLayout
    lateinit var to_type_ll: LinearLayout
    private var selectedType: String = ""
    private var selectedFromType: String = ""
    private var selectedCommuteFrequency: String = ""

    val sharedViewModel: ProfileSharedViewModel by activityViewModels()

    lateinit var textViewTitle: TextView
    private var isEditMode = false

    private lateinit var radioGroup: RadioGroup

    lateinit var layoutHome: LinearLayout
    lateinit var layoutWork: LinearLayout
    lateinit var layoutSchool: LinearLayout
    lateinit var layoutTravel: LinearLayout

    lateinit var home_img: ImageView
    lateinit var work_img: ImageView
    lateinit var college_img: ImageView
    lateinit var travel_img: ImageView

    lateinit var home_txt: TextView
    lateinit var work_txt: TextView
    lateinit var clg_text: TextView
    lateinit var travel_txt: TextView

    lateinit var from_home: LinearLayout
    lateinit var from_work: LinearLayout
    lateinit var from_school: LinearLayout
    lateinit var from_travel: LinearLayout

    lateinit var from_home_img: ImageView
    lateinit var from_work_img: ImageView
    lateinit var from_college_img: ImageView
    lateinit var from_travel_img: ImageView

    lateinit var from_home_txt: TextView
    lateinit var from_work_txt: TextView
    lateinit var from_clg_text: TextView
    lateinit var from_travel_txt: TextView

    lateinit var preference_name: EditText


    private var selectedLayout: LinearLayout? = null

    companion object {
        const val AUTOCOMPLETE_REQUEST_CODE_FROM = 1
        const val AUTOCOMPLETE_REQUEST_CODE_TO = 2// You can use any unique integer here
    }


    private val selectedDays = mutableListOf<String>()

    private val addPereferenceViewModel :AddPereferenceViewModel by viewModels {
        // Create UserRepository instance with ApiService
        val userRepository = UserRepository(RetrofitInstance.apiService)
        // Pass UserRepository to the factory
        AddPereferenceViewModelFactory(userRepository)
    }

    fun addPreference(preference: AddPreferenceRequest) {
        addPereferenceViewModel.addpreference(preference).observe(viewLifecycleOwner) { result ->
            when (result) {
                is ApiResult.Success<*> -> {
                    showAlertDialog("Success", "Preference added successfully")
                    findNavController().navigate(R.id.action_AddPreferences_to_DashFragment)
                }
                is ApiResult.Error -> {
                    if (result.exception is retrofit2.HttpException && result.exception.code() == 409) {
                        showAlertDialog("Error", "Failed to add preference. Preference With Name Already Exists")
                    } else if (result.exception is retrofit2.HttpException && result.exception.code() == 500) {
                        showAlertDialog("Error", "Failed to add preference. Internal server error")
                    } else {
                        showAlertDialog("Error", "Failed to add preference.")
                    }
                }
                is ApiResult.Loading -> {
                }
            }
        }
    }

    fun editPreference(preference: AddPreferenceRequest) {
        addPereferenceViewModel.editpreference(preference).observe(viewLifecycleOwner) { result ->
            when (result) {
                is ApiResult.Success<*> -> {
                    showAlertDialog("Success", "Preference Updated successfully")
                    findNavController().navigate(R.id.action_AddPreferences_to_DashFragment)
                }
                is ApiResult.Error -> {
                    if (result.exception is retrofit2.HttpException && result.exception.code() == 409) {
                        showAlertDialog("Error", "Failed to edit preference. Preference With Name Already Exists")
                    } else if (result.exception is retrofit2.HttpException && result.exception.code() == 422) {
                        showAlertDialog("Error", "Failed to edit preference.Preference doesn't exists")
                    }
                    else if (result.exception is retrofit2.HttpException && result.exception.code() == 500) {
                        showAlertDialog("Error", "Failed to edit preference. Internal server error")
                    } else {
                        showAlertDialog("Error", "Failed to edit preference.")
                    }
                }
                is ApiResult.Loading -> {
                }
            }
        }
    }
    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_add_preferences, container, false)
        start_time_ll = view.findViewById(R.id.start_time_ll)
        end_time_ll = view.findViewById(R.id.end_time_ll)
        timePicker_startTime = view.findViewById(R.id.timePicker_startTime)
        timePicker_EndTime = view.findViewById(R.id.timePicker_EndTime)
        calendar_imgview = view.findViewById(R.id.calendar_imgview)
        startTime_txtview = view.findViewById(R.id.startTime_txtview)
        EndTime_txtview = view.findViewById(R.id.EndTime_txtview)
        btn_save = view.findViewById(R.id.btn_save)
        edt_from = view.findViewById(R.id.edt_from)
        iv_from = view.findViewById(R.id.iv_from_location)
        edt_to = view.findViewById(R.id.edt_to)
        iv_to = view.findViewById(R.id.iv_to_location)
        occupation_name = view.findViewById(R.id.occupation_name)
        custom_calendar_txt = view.findViewById(R.id.custom_calendar_txt)
        calendar_days = view.findViewById(R.id.calendar_days)
        switchButton = view.findViewById(R.id.switchButton)

        buttonSunday = view.findViewById(R.id.buttonSunday)
        buttonMonday = view.findViewById(R.id.buttonMonday)
        buttonTuesday = view.findViewById(R.id.buttonTuesday)
        buttonWednesday = view.findViewById(R.id.buttonWednesday)
        buttonThursday = view.findViewById(R.id.buttonThursday)
        buttonFriday = view.findViewById(R.id.buttonFriday)
        buttonSaturday = view.findViewById(R.id.buttonSaturday)
        tvDaily = view.findViewById(R.id.tvDaily)

        radioGroup = view.findViewById(R.id.radioGroup)

        layoutHome = view.findViewById(R.id.Home)
        layoutWork = view.findViewById(R.id.work)
        layoutSchool = view.findViewById(R.id.school)
        layoutTravel = view.findViewById(R.id.travel)

        home_img = view.findViewById(R.id.home_img)
        work_img = view.findViewById(R.id.work_img)
        college_img = view.findViewById(R.id.college_img)
        travel_img = view.findViewById(R.id.travel_img)

        home_txt = view.findViewById(R.id.home_txt)
        work_txt = view.findViewById(R.id.work_txt)
        clg_text = view.findViewById(R.id.clg_text)
        travel_txt = view.findViewById(R.id.travel_txt)
        days_picker_layout = view.findViewById(R.id.days_picker_layout)
        from_type_ll = view.findViewById(R.id.from_type_ll)


        from_home = view.findViewById(R.id.from_home)
        from_home_img = view.findViewById(R.id.from_home_img)
        from_home_txt = view.findViewById(R.id.from_home_txt)

        from_work = view.findViewById(R.id.from_work)
        from_work_img = view.findViewById(R.id.from_work_img)
        from_work_txt = view.findViewById(R.id.from_work_txt)

        from_school = view.findViewById(R.id.from_school)
        from_college_img = view.findViewById(R.id.from_college_img)
        from_clg_text = view.findViewById(R.id.from_clg_text)

        from_travel = view.findViewById(R.id.from_travel)
        from_travel_img = view.findViewById(R.id.from_travel_img)
        from_travel_txt = view.findViewById(R.id.from_travel_txt)

        preference_name = view.findViewById(R.id.preference_name)
        to_type_ll = view.findViewById(R.id.to_type_ll)

        val dotTextView: TextView = view.findViewById(R.id.daily_dot_txt)
        val spannableString = SpannableString("\u2022") // Unicode character for a bullet
        spannableString.setSpan(StyleSpan(Typeface.BOLD), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        dotTextView.text = spannableString

        customizeSwitchColor(switchButton)

        calendar_days.setOnClickListener {
            days_picker_layout.visibility = View.VISIBLE
        }

        radioGroup = view.findViewById(R.id.radioGroup)

        radioGroup.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.radio_daily_commuter -> {
                    isDailyCommuter = true
                }
                R.id.radio_new_commuter -> {
                    isDailyCommuter = false

                }
            }
        }

        days_picker_layout.children.forEach { view ->
            if (view is TextView) {
                view.setOnClickListener {
// Get the ID of the clicked TextView
                    val textViewId = view.id
// Define a variable to hold the day name
                    val dayName = when (textViewId) {
                        R.id.buttonSunday -> "Sun"
                        R.id.buttonMonday -> "Mon"
                        R.id.buttonTuesday -> "Tue"
                        R.id.buttonWednesday -> "Wed"
                        R.id.buttonThursday -> "Thu"
                        R.id.buttonFriday -> "Fri"
                        R.id.buttonSaturday -> "Sat"
                        else -> ""
                    }
// Update the background of the selected day
                    if (dayName in selectedDays) {
                        selectedDays.remove(dayName)
                        view.setBackgroundResource(R.drawable.days_button_background)
                    } else {
                        selectedDays.add(dayName)
                        view.setBackgroundResource(R.drawable.day_selected_background)
                    }
// Update the text of custom_calendar_txt
                    custom_calendar_txt.text = selectedDays.sorted().joinToString(", ")
                    updateCustomCalendarText(custom_calendar_txt)
                }
            }
        }

        from_home.setOnClickListener {
            if (selectedLayout != from_home) {
                resetfromLayouts()
                from_home.setBackgroundResource(R.drawable.preference_type_highlighted_background)
                from_home_img.setColorFilter(ContextCompat.getColor(requireContext(), R.color.white))
                from_home_txt.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                selectedFromType = "Home"
                selectedLayout = from_home
            }
        }
        from_work.setOnClickListener {
            if (selectedLayout != from_work) {
                resetfromLayouts()
                from_work.setBackgroundResource(R.drawable.preference_type_highlighted_background)
                from_work_img.setColorFilter(ContextCompat.getColor(requireContext(), R.color.white))
                from_work_txt.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                selectedFromType = "Work"
                selectedLayout = from_work
            }
        }
        from_school.setOnClickListener {
            if (selectedLayout != from_school) {
                resetfromLayouts()
                from_school.setBackgroundResource(R.drawable.preference_type_highlighted_background)
                from_college_img.setColorFilter(ContextCompat.getColor(requireContext(), R.color.white))
                from_clg_text.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                selectedFromType = "School"
                selectedLayout = from_school
            }
        }
        from_travel.setOnClickListener {
            if (selectedLayout != from_travel) {
                resetfromLayouts()
                from_travel.setBackgroundResource(R.drawable.preference_type_highlighted_background)
                from_travel_img.setColorFilter(ContextCompat.getColor(requireContext(), R.color.white))
                from_travel_txt.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                selectedFromType = "Travel"
                selectedLayout = from_travel
            }
        }

        layoutHome.setOnClickListener {
            if (selectedFromType != "Home" && selectedLayout != layoutHome ) {
                resetLayouts()
                layoutHome.setBackgroundResource(R.drawable.preference_type_highlighted_background)
                home_img.setColorFilter(ContextCompat.getColor(requireContext(), R.color.white))
                home_txt.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                selectedType = "Home"
                selectedLayout = layoutHome
            }else {
                // Display an error message if the "from" and "to" types are the same
                Toast.makeText(requireContext(), "From and To types cannot be the same", Toast.LENGTH_SHORT).show()
            }
        }
        layoutWork.setOnClickListener {
            if (selectedFromType != "Work" && selectedLayout != layoutWork) {
                resetLayouts()
                layoutWork.setBackgroundResource(R.drawable.preference_type_highlighted_background)
                work_img.setColorFilter(ContextCompat.getColor(requireContext(), R.color.white))
                work_txt.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                selectedType = "Work"
                selectedLayout = layoutWork
            }else {
                // Display an error message if the "from" and "to" types are the same
                Toast.makeText(requireContext(), "From and To types cannot be the same", Toast.LENGTH_SHORT).show()
            }
        }
        layoutSchool.setOnClickListener {
            if (selectedFromType != "School" && selectedLayout != layoutSchool) {
                resetLayouts()
                layoutSchool.setBackgroundResource(R.drawable.preference_type_highlighted_background)
                college_img.setColorFilter(ContextCompat.getColor(requireContext(), R.color.white))
                clg_text.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                selectedType = "School"
                selectedLayout = layoutSchool
            }else {
                // Display an error message if the "from" and "to" types are the same
                Toast.makeText(requireContext(), "From and To types cannot be the same", Toast.LENGTH_SHORT).show()
            }
        }
        layoutTravel.setOnClickListener {
            if (selectedFromType != "Travel" && selectedLayout != layoutTravel) {
                resetLayouts()
                layoutTravel.setBackgroundResource(R.drawable.preference_type_highlighted_background)
                travel_img.setColorFilter(ContextCompat.getColor(requireContext(), R.color.white))
                travel_txt.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                selectedType = "Travel"
                selectedLayout = layoutTravel
            }  else {
                // Display an error message if the "from" and "to" types are the same
                Toast.makeText(requireContext(), "From and To types cannot be the same", Toast.LENGTH_SHORT).show()
            }
        }

        val dailyLayout = view.findViewById<LinearLayout>(R.id.daily)
        val weekdaysLayout = view.findViewById<LinearLayout>(R.id.weekdays)
        val weekendsLayout = view.findViewById<LinearLayout>(R.id.weekends)

        dailyLayout.setOnClickListener {
            selectedCommuteFrequency = "Daily"
            highlightSelectedFrequency(dailyLayout, weekdaysLayout, weekendsLayout)

            selectedDays.clear()
            selectedDays.addAll(listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"))
            updateCustomCalendarText(custom_calendar_txt)
        }

        switchButton.setOnCheckedChangeListener { buttonView, isChecked ->
            days_picker_layout.visibility = View.GONE
            Prefer_Metro = isChecked
        }


        weekdaysLayout.setOnClickListener {
            selectedCommuteFrequency = "Weekdays"
            highlightSelectedFrequency(dailyLayout, weekdaysLayout, weekendsLayout)

            selectedDays.clear()
            selectedDays.addAll(listOf("Mon", "Tue", "Wed", "Thu", "Fri"))
            updateCustomCalendarText(custom_calendar_txt)
        }

        weekendsLayout.setOnClickListener {
            selectedCommuteFrequency = "Weekends"
            highlightSelectedFrequency(dailyLayout, weekdaysLayout, weekendsLayout)

            selectedDays.clear()
            selectedDays.addAll(listOf("Sat", "Sun"))
            updateCustomCalendarText(custom_calendar_txt)
        }

        edt_from.setOnClickListener {
            from_type_ll.visibility = View.VISIBLE
            openPlacesSearch(AUTOCOMPLETE_REQUEST_CODE_FROM)
        }

        iv_from.setOnClickListener {
            openPlacesSearch(AUTOCOMPLETE_REQUEST_CODE_FROM)
        }


        edt_to.setOnClickListener {
            from_type_ll.visibility = View.GONE
            to_type_ll.visibility = View.VISIBLE
            openPlacesSearch(AUTOCOMPLETE_REQUEST_CODE_TO)
        }

        iv_to.setOnClickListener {
            openPlacesSearch(AUTOCOMPLETE_REQUEST_CODE_TO)
        }

        val dayButtons = listOf(
            buttonSunday, buttonMonday, buttonTuesday,
            buttonWednesday, buttonThursday, buttonFriday,buttonSaturday
        )


        start_time_ll.setOnClickListener {
            to_type_ll.visibility = View.GONE
            showTimePickerDialog(true)
        }

        end_time_ll.setOnClickListener {
            to_type_ll.visibility = View.GONE
            showTimePickerDialog(false)
        }

        btn_save.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {

                val fromLocation = edt_from.text.toString()
                val toLocation = edt_to.text.toString()
                val startTime = startTime_txtview.text.toString()
                val returnTime = EndTime_txtview.text.toString()
                val occupation = occupation_name.text.toString()
                val name = preference_name.text.toString()


                val days = selectedDays.joinToString(", ")

                if (fromLocation.isEmpty()) {
                    showAlertDialog("Error", "From location cannot be empty")
                    return
                }

                if (toLocation.isEmpty()) {
                    showAlertDialog("Error", "To location cannot be empty")
                    return
                }

                val userData = sharedViewModel.getUserData()
                userData?.let {
                    try {
                       if (isEditMode){
                           val preferenceRequest = AddPreferenceRequest(preference.preferenceId,fromLocation,toLocation,startTime,returnTime,
                               name,selectedFromType,selectedType,selectedCommuteFrequency,selectedDays,Prefer_Metro,isDailyCommuter,occupation,it.userID)
                           editPreference(preferenceRequest)
                       } else {
                           val preferenceRequest = AddPreferenceRequest("",fromLocation,toLocation,startTime,returnTime,
                               name,selectedFromType,selectedType,selectedCommuteFrequency,selectedDays,Prefer_Metro ,isDailyCommuter,occupation,it.userID)
                           addPreference(preferenceRequest)

                       }
                    // Proceed with using registerUser for API call or other logic
                    } catch (e: NumberFormatException) {
                        // Handle the case where the mobile number is not a valid Long
                        Toast.makeText(context, "Invalid mobile number format", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
        return view
    }

    private fun showTimePickerDialog(isStartTime: Boolean) {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_time_picker, null)
        val timePicker = dialogView.findViewById<TimePicker>(R.id.timePicker).apply {
            setIs24HourView(false)
        }
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogView)
            .create()

        dialogView.findViewById<Button>(R.id.timePickerOkButton).setOnClickListener {
            val hour = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) timePicker.hour else timePicker.currentHour
            val minute = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) timePicker.minute else timePicker.currentMinute
            val selectedTime = formatTime(hour, minute)

            // Perform validation based on whether it's start or end time being set
            if (isStartTime) {
                // For start time, compare with current end time (if set)
                if (EndTime_txtview.text.isNotEmpty() && !validateStartAndEndTime(selectedTime, EndTime_txtview.text.toString())) {
                    showAlertDialog("Error", "Start time must be before end time.")
                } else {
                    startTime_txtview.text = selectedTime
                }
            } else {
                // For end time, compare with current start time
                if (startTime_txtview.text.isNotEmpty() && !validateStartAndEndTime(startTime_txtview.text.toString(), selectedTime)) {
                    showAlertDialog("Error", "End time must be after start time.")
                } else {
                    EndTime_txtview.text = selectedTime
                }
            }

            dialog.dismiss()
        }

        dialog.show()
    }

    private fun resetLayouts() {
        selectedLayout?.apply {
            setBackgroundResource(R.drawable.text_box_shape)
            val imgView = getChildAt(0) as ImageView
            val textView = getChildAt(1) as TextView
            imgView.setColorFilter(ContextCompat.getColor(requireContext(), R.color.dark_maroon))
            textView.setTextColor(ContextCompat.getColor(requireContext(), R.color.dark_maroon))
        }
        selectedLayout = null
    }

    private fun resetfromLayouts() {
        selectedLayout?.apply {
            setBackgroundResource(R.drawable.text_box_shape)
            val imgView = getChildAt(0) as ImageView
            val textView = getChildAt(1) as TextView
            imgView.setColorFilter(ContextCompat.getColor(requireContext(), R.color.dark_maroon))
            textView.setTextColor(ContextCompat.getColor(requireContext(), R.color.dark_maroon))
        }
        selectedLayout = null
    }

    private fun formatTime(hour: Int, minute: Int): String {
        val amPm = if (hour < 12) "AM" else "PM"
        val formattedHour = if (hour == 0 || hour == 12) 12 else hour % 12
        return String.format("%02d:%02d %s", formattedHour, minute, amPm)
    }

    private fun validateStartAndEndTime(startTime: String, endTime: String): Boolean {
        val start = parseTime(startTime)
        val end = parseTime(endTime)

        // Convert to 24-hour format for comparison
        val startHour24 = if (start.third == "PM" && start.first != 12) start.first + 12 else if (start.third == "AM" && start.first == 12) 0 else start.first
        val endHour24 = if (end.third == "PM" && end.first != 12) end.first + 12 else if (end.third == "AM" && end.first == 12) 0 else end.first

        val startMinutesTotal = startHour24 * 60 + start.second
        val endMinutesTotal = endHour24 * 60 + end.second

        return startMinutesTotal < endMinutesTotal
    }

    private fun parseTime(time: String): Triple<Int, Int, String> {
        val parts = time.split(" ")
        val timeParts = parts[0].split(":").map { it.toInt() }
        val amPm = parts[1]
        return Triple(timeParts[0], timeParts[1], amPm)
    }
    private fun customizeSwitchColor(switchButton:Switch) {

// Define fully opaque colors for the switch thumb and track
        val thumbColorOn = Color.parseColor("#FFFFFFFF") // White with full opacity
        val thumbColorOff = Color.parseColor("#FFBDBDBD") // Grey with full opacity
        val trackColorOn = Color.parseColor("#FF41c70a") // Green with full opacity
        val trackColorOff = Color.parseColor("#FFEEEEEE") // Light grey with full opacity

// Define the color state list for the thumb
        val thumbColors = ColorStateList(
            arrayOf(
                intArrayOf(android.R.attr.state_checked), // Thumb color for "ON" state
                intArrayOf(-android.R.attr.state_checked) // Thumb color for "OFF" state
            ),
            intArrayOf(
                thumbColorOn,
                thumbColorOff
            )
        )

// Define the color state list for the track
        val trackColors = ColorStateList(
            arrayOf(
                intArrayOf(android.R.attr.state_checked), // Track color for "ON" state
                intArrayOf(-android.R.attr.state_checked) // Track color for "OFF" state
            ),
            intArrayOf(
                trackColorOn,
                trackColorOff
            )
        )

// Set the thumb color state list to the switch
        switchButton.thumbTintList = thumbColors
// Set the track color state list to the switch
        switchButton.trackTintList = trackColors

    }

    private fun showAlertDialog(title: String, message: String) {
        AlertDialog.Builder(requireContext()).apply {
            setTitle(title)
            setMessage(message)
            setPositiveButton(android.R.string.ok) { dialog, which ->
                dialog.dismiss()
            }
            create()
            show()
        }
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        radioGroup.check(R.id.radio_daily_commuter)


        val radioDailyCommuter: RadioButton = view.findViewById(R.id.radio_daily_commuter)
        val radioNewCommuter: RadioButton = view.findViewById(R.id.radio_new_commuter)

        // Apply the color state list to the radio buttons
        val colorStateList = GlobalVariables.radioButtonColorStateList(requireContext())
        radioDailyCommuter.buttonTintList = colorStateList
        radioNewCommuter.buttonTintList = colorStateList

        // Assuming 'left_arrow' is the ID of your ImageView
        val leftArrowImageView: ImageView = view.findViewById(R.id.left_arrow)
        leftArrowImageView.setOnClickListener {
            // Use the findNavController() from the Navigation component to navigate back
            findNavController().navigateUp()
        }

        textViewTitle = view.findViewById(R.id.PreferencesTitle)
        arguments?.getSerializable("preferenceDetails")?.let { serializable ->
            if (serializable is Preference) {
                preference = serializable
                // Use the preference object to populate your UI fields
                setupUIForEditing(preference)
                // Populate other fields as necessary
                textViewTitle.text = "Edit Preference"
                isEditMode = true
            } else {
                Toast.makeText(requireContext(), "something else", Toast.LENGTH_SHORT).show()
            }
        }

        val dailyLayout = view.findViewById<LinearLayout>(R.id.daily)
        val weekdaysLayout = view.findViewById<LinearLayout>(R.id.weekdays)
        val weekendsLayout = view.findViewById<LinearLayout>(R.id.weekends)

        selectedCommuteFrequency = "Daily"
        highlightSelectedFrequency(dailyLayout, weekdaysLayout, weekendsLayout)

   }

    private fun setupUIForEditing(preference: Preference) {
        // Set up all UI fields based on the preference object
        edt_from.setText(preference.fromLocation)
        edt_to.setText(preference.toLocation)
        startTime_txtview.text = preference.startTime
        EndTime_txtview.text = preference.returnTime
        preference_name.setText(preference.name)
        occupation_name.setText(preference.occupation)
        if (preference.name.equals("Work")){
            resetLayouts()
            layoutWork.setBackgroundResource(R.drawable.preference_type_highlighted_background)
            work_img.setColorFilter(ContextCompat.getColor(requireContext(), R.color.white))
            work_txt.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
        } else if (preference.name.equals("College")|| preference.name.equals("School")){
            resetLayouts()
            layoutSchool.setBackgroundResource(R.drawable.preference_type_highlighted_background)
            college_img.setColorFilter(ContextCompat.getColor(requireContext(), R.color.white))
            clg_text.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            selectedType = "School"
        } else if (preference.name.equals("Travel")){
            resetLayouts()
            layoutTravel.setBackgroundResource(R.drawable.preference_type_highlighted_background)
            travel_img.setColorFilter(ContextCompat.getColor(requireContext(), R.color.white))
            travel_txt.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
        }

        if (preference.preferMetro){
            switchButton.isChecked = true
        } else {
            switchButton.isChecked = false
        }

        selectCommuteFrequency(preference.occurrenceType)
        selectDays(preference.days.toString())
        textViewTitle.text = "Edit Preference"
    }

    private fun selectType(type: String) {
        // Implement logic to highlight the selected type (Work, School, Travel)
    }

    private fun selectCommuteFrequency(frequency: String) {
        // Implement logic to highlight the selected commute frequency (Daily, Weekdays, Weekends)
    }


    private fun selectDays(daysString: String) {
        // Split the days string by comma and trim spaces
        val daysList = daysString.split(",").map { it.trim() }
        selectedDays.clear()
        selectedDays.addAll(daysList)
        // Now you have your 'selectedDays' list populated with days from the string
        // Update your UI to reflect these selections
        updateDaySelectionUI()
    }

    private fun updateDaySelectionUI() {
        // Assuming you have buttons or some UI elements to indicate selected days
        // Update their state here based on 'selectedDays'
        val allButtons = mapOf(
            "Mon" to buttonMonday,
            "Tue" to buttonTuesday,
            "Wed" to buttonWednesday,
            // Add mappings for other days...
        )

        allButtons.forEach { (day, button) ->
            button.isSelected = selectedDays.contains(day)
            // You might need to change the background or text color of the button based on whether it is selected
        }
    }

    private fun highlightSelectedType(vararg layouts: LinearLayout) {
        layouts.forEach { layout ->
            if (layout.tag == selectedType) {
                // Highlight this layout with the oval shape background
                val highlightDrawable = ContextCompat.getDrawable(requireContext(), R.drawable.preference_type_highlighted_background)
                layout.background = highlightDrawable
            } else {
                // Revert to the default look for other layouts
                val defaultDrawable = ContextCompat.getDrawable(requireContext(), R.drawable.preference_type_default_background)
                layout.background = defaultDrawable
            }
        }
    }


    private fun highlightSelectedFrequency(vararg layouts: LinearLayout) {
        layouts.forEach { layout ->
            // Find the TextViews within the LinearLayout
            val textView1 = layout.getChildAt(0) as TextView
            val textView2 = layout.getChildAt(1) as TextView

            if (layout.tag == selectedCommuteFrequency) {
                // Change the text color of the TextViews for the selected frequency
                textView1.setTextColor(ContextCompat.getColor(requireContext(), R.color.teal_200))
                textView2.setTextColor(ContextCompat.getColor(requireContext(), R.color.teal_200))
            } else {
                // Revert the text color of the TextViews for the non-selected frequencies
                textView1.setTextColor(ContextCompat.getColor(requireContext(), R.color.preference_txt_color))
                textView2.setTextColor(ContextCompat.getColor(requireContext(), R.color.preference_txt_color))
            }
        }
    }


    fun openPlacesSearch(requestCode: Int) {
        val fieldList = listOf(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG)
        val intent = Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fieldList).build(requireContext())
        startActivityForResult(intent, requestCode) // Pass the request code here
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK && data != null) {
            val place = Autocomplete.getPlaceFromIntent(data)
            when (requestCode) {
                AUTOCOMPLETE_REQUEST_CODE_FROM -> {
                    edt_from.setText(place.name)
                }
                AUTOCOMPLETE_REQUEST_CODE_TO -> {
                    edt_to.setText(place.name)
                }
            }
        } else if (resultCode == AutocompleteActivity.RESULT_ERROR && data != null) {
            val status = Autocomplete.getStatusFromIntent(data)
            Toast.makeText(context, status.statusMessage ?: "Error", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleSelection(day: String) {
        if (selectedDays.contains(day)) {
            selectedDays.remove(day)
        } else {
            selectedDays.add(day)
        }
    }

    private fun updateCustomCalendarText(textView: TextView) {
        val selectedDaysString = selectedDays.joinToString(",") { day ->
            when (day) {
                "Mon" -> {
                    buttonMonday.setTextColor(Color.WHITE)
                    "Mon"
                }
                "Tue" -> {
                    buttonTuesday.setTextColor(Color.WHITE)
                    "Tue"
                }
                "Wed" -> {
                    buttonWednesday.setTextColor(Color.WHITE)
                    "Wed"
                }
                "Thu" -> {
                    buttonThursday.setTextColor(Color.WHITE)
                    "Thu"
                }
                "Fri" -> {
                    buttonFriday.setTextColor(Color.WHITE)
                    "Fri"
                }
                "Sat" -> {
                    buttonSaturday.setTextColor(Color.WHITE)
                    "Sat"
                }
                "Sun" -> {
                    buttonSunday.setTextColor(Color.WHITE)
                    "Sun"
                }
                else -> ""
            }
        }
        textView.text = selectedDaysString

// Set text color to black for unselected days
        val textColorBlack = Color.BLACK

        if (!selectedDays.contains("Mon")) buttonMonday.setTextColor(textColorBlack)
        if (!selectedDays.contains("Tue")) buttonTuesday.setTextColor(textColorBlack)
        if (!selectedDays.contains("Wed")) buttonWednesday.setTextColor(textColorBlack)
        if (!selectedDays.contains("Thu")) buttonThursday.setTextColor(textColorBlack)
        if (!selectedDays.contains("Fri")) buttonFriday.setTextColor(textColorBlack)
        if (!selectedDays.contains("Sat")) buttonSaturday.setTextColor(textColorBlack)
        if (!selectedDays.contains("Sun")) buttonSunday.setTextColor(textColorBlack)
    }
    private fun areFromAndTypeSame(): Boolean {
        return selectedFromType == selectedType
    }

}