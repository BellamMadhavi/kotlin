package com.motivitylabs.bustrackingapp.repository

import com.motivitylabs.bustrackingapp.model.request.AddPreferenceRequest
import com.motivitylabs.bustrackingapp.model.request.AuthSignInRequest
import com.motivitylabs.bustrackingapp.model.request.RegisterRequest
import com.motivitylabs.bustrackingapp.model.request.UpdateProfileRequest
import com.motivitylabs.bustrackingapp.model.request.VerifyOtpRequest
import com.motivitylabs.bustrackingapp.network.ApiService

// UserRepository.kt
class UserRepository(private val apiService: ApiService) : BaseRepository() {

    suspend fun sendOtp(toPhoneNumber: String) = apiCall {
        apiService.sendOtp(toPhoneNumber)
    }

    suspend fun verifyOtp(request: VerifyOtpRequest)= apiCall {
        apiService.verifyOtp(request)
    }


    suspend fun authSignIn(emailaddress: String)= apiCall {
        apiService.authsign(emailaddress)
    }

    suspend fun registerUser(request: RegisterRequest)= apiCall {
        apiService.registerUser(request)
    }
    suspend fun updateProfile(request: UpdateProfileRequest)= apiCall {
        apiService.updateProfile(request)
    }
    // Implement additional API calls following the same pattern


    suspend fun addpreference(preferencerequest: AddPreferenceRequest)= apiCall {
        apiService.addpreference(preferencerequest)
    }

    suspend fun editpreference(preferencerequest: AddPreferenceRequest)= apiCall {
        apiService.editpreference(preferencerequest)
    }

    suspend fun fetchPreferences(preferencerequest: String)= apiCall {
        apiService.fetchPreferences(preferencerequest)
    }

    suspend fun deletePreference(preferenceId: String) = apiCall {
        apiService.deletePreference(preferenceId)
    }

    suspend fun getNotifications(userId: String) = apiCall {
        apiService.getNotifications(userId)
    }

    suspend fun fetchUserProfile(userId: String) = apiCall {
        apiService.fetchUserProfile(userId)
    }

    suspend fun logoutUser(toPhoneNumber: String) = apiCall {
        apiService.logoutUser(toPhoneNumber)
    }
}
