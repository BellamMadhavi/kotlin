package com.motivitylabs.bustrackingapp.model.response

import com.google.gson.annotations.SerializedName

data class UserData(
    @SerializedName("userID") val userID: String,
    @SerializedName("fullName") val fullName: String,
    @SerializedName("email") val email: String,
    @SerializedName("contactNumber") val contactNumber: String,
    @SerializedName("dailyCommuter") val dailyCommuter: Boolean

)

data class RegisterResponse(
    @SerializedName("responseData") val responseData: UserData,
    @SerializedName("success") val success: Boolean,
    @SerializedName("errorMessages") val errorMessages: String
)
