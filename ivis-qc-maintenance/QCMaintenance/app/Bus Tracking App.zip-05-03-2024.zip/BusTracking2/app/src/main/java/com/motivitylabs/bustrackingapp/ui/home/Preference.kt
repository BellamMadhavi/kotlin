package com.motivitylabs.bustrackingapp.ui.home

import java.io.Serializable

data class Preference(
    val preferenceId: String,
    val fromLocation: String,
    val toLocation: String,
    val startTime: String,
    val returnTime: String,
    val name: String,
    val fromType: String,
    val toType: String,
    val occurrenceType: String,
    val days: List<String>,
    val preferMetro: Boolean,
    val dailyCommuter: Boolean,
    val occupation: String,

): Serializable
