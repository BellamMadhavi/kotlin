package com.motivitylabs.bustrackingapp

import android.content.Context
import android.content.res.ColorStateList
import androidx.core.content.ContextCompat

object GlobalVariables {
    fun radioButtonColorStateList(context: Context): ColorStateList {
        return ColorStateList(
            arrayOf(
                intArrayOf(-android.R.attr.state_checked), // Unchecked state
                intArrayOf(android.R.attr.state_checked)   // Checked state
            ),
            intArrayOf(
                ContextCompat.getColor(context, R.color.dark_grey), // Unchecked color
                ContextCompat.getColor(context, R.color.checkedRadioButtonColor)    // Checked color
            )
        )
    }
}