package com.motivitylabs.bustrackingapp

class Constants {
}