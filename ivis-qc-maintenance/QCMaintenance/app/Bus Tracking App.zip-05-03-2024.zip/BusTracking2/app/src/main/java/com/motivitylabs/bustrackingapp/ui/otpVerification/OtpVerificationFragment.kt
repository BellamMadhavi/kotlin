package com.motivitylabs.bustrackingapp.ui.otpVerification

import android.opengl.Visibility
import android.os.Bundle
import android.os.CountDownTimer
import android.preference.PreferenceManager
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.google.gson.Gson
import com.motivitylabs.bustrackingapp.GlobalConfig
import com.motivitylabs.bustrackingapp.R
import com.motivitylabs.bustrackingapp.model.request.VerifyOtpRequest
import com.motivitylabs.bustrackingapp.model.response.UserData
import com.motivitylabs.bustrackingapp.model.response.VerifyOtpResponse
import com.motivitylabs.bustrackingapp.network.RetrofitInstance
import com.motivitylabs.bustrackingapp.network.RetrofitInstance.apiService
import com.motivitylabs.bustrackingapp.repository.UserRepository
import com.motivitylabs.bustrackingapp.ui.fragment.LoginFragment
import com.motivitylabs.bustrackingapp.ui.viewmodel.LoginViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.LoginViewModelFactory
import com.motivitylabs.bustrackingapp.ui.viewmodel.OtpVerificationViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.OtpVerificationViewModelFactory
import com.motivitylabs.bustrackingapp.ui.viewmodel.ProfileSharedViewModel
import com.motivitylabs.bustrackingapp.ui.viewmodel.SharedViewModel
import com.motivitylabs.bustrackingapp.util.ApiResult
import retrofit2.HttpException

class OtpVerificationFragment : Fragment() {

    private lateinit var txtResend: TextView
    private lateinit var otpFields: List<EditText>
    private lateinit var txtTimer: TextView
    private  lateinit var otpNotificationTxt: TextView

    lateinit var btn_verify: LinearLayout
    lateinit var txt_phone_num: TextView
    private var countDownTimer: CountDownTimer? = null
    private lateinit var viewModel: SharedViewModel


    private val sendOtpViewModel: LoginViewModel by viewModels {
        // Create UserRepository instance with ApiService
        val userRepository = UserRepository(RetrofitInstance.apiService)
        // Pass UserRepository to the factory
        LoginViewModelFactory(userRepository)
    }

    private lateinit var sendOtpSharedViewModel: SharedViewModel

    companion object {
        // Countdown duration of 2 minutes in milliseconds
        const val COUNTDOWN_DURATION: Long = 120000
    }


    // Obtain a reference to the shared view model
    val sharedViewModel: ProfileSharedViewModel by activityViewModels()

    private val userRepository by lazy {
        UserRepository(apiService) // Make sure to provide the actual ApiService instance
    }

    private val otpVerificationViewModel: OtpVerificationViewModel by viewModels {
        OtpVerificationViewModelFactory(userRepository)
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_otp_verification, container, false)

        btn_verify = view.findViewById(R.id.btn_verify)
        txtResend = view.findViewById(R.id.txt_resend_otp)
        txtTimer = view.findViewById(R.id.txt_timer) // Assuming you have a TextView for the timer
        otpNotificationTxt = view.findViewById(R.id.txt_otp_notification)



        // Hide OTP expired message initially
        otpNotificationTxt.visibility = View.GONE
        // Disable resend button initially
        txtResend.isEnabled = false
        updateResendButtonAppearance(false)

        val imgEditPhone: ImageView = view.findViewById(R.id.iv_edit_icon)

        // Initialize your OTP EditTexts here
        otpFields = listOf(
            view.findViewById(R.id.otp_field_1),
            view.findViewById(R.id.otp_field_2),
            view.findViewById(R.id.otp_field_3),
            view.findViewById(R.id.otp_field_4),
            view.findViewById(R.id.otp_field_5),
            view.findViewById(R.id.otp_field_6)
        )

        setupOtpFields()
        startOtpCountdownTimer()
        setupResendButton()

// Edit icon click listener
        imgEditPhone.setOnClickListener {
            navigateBackWithPhoneNumber()
        }

        txt_phone_num = view.findViewById(R.id.txt_phone_num)

        viewModel = ViewModelProvider(requireActivity()).get(SharedViewModel::class.java)

        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)

        val mobileNumber = sharedPreferences.getString("mobile_number", "")
        val editableMobileNumber = Editable.Factory.getInstance().newEditable(mobileNumber)
        txt_phone_num.text = editableMobileNumber


        btn_verify.setOnClickListener {
            // Assuming otpFields are your EditText inputs for the OTP
            sendOtp()
        }
      return view
    }

    private fun updateResendButtonAppearance(enabled: Boolean) {
        if (enabled) {
            txtResend.isEnabled = true
            txtTimer.visibility = View.GONE
            txtResend.setBackgroundResource(R.color.purple_500) // Use your enabled color
            txtResend.setTextColor(ContextCompat.getColor(requireContext(), R.color.white)) // Use your enabled text color
        } else {
            txtResend.isEnabled = false
            txtResend.setTextColor(ContextCompat.getColor(requireContext(), R.color.black)) // Use your disabled text color
        }
    }


    private fun navigateBackWithPhoneNumber() {
        val mobileNumber = txt_phone_num.text.toString()
        viewModel.setMobileNumber(mobileNumber)

        findNavController().navigate(R.id.action_OtpVerificationFragment_to_LoginFragment)

    }

    private  fun sendOtp() {
        val otpInput = otpFields.joinToString(separator = "") { it.text.toString() }
        val countryCode = "+91" // Define how you get this
        val mobileNumber1 = txt_phone_num.text.toString()

        if (GlobalConfig.debugMode) {
            dummyAPICall()
        } else {
            sendOtpAPICall()
        }
    }

    private  fun dummyAPICall() {
//        "userID": "f5f17ed9-c5a9-4034-860a-4e47890a4ffe",
        //                                "fullName": "santhosh",
        //                                "email": "santhosh.karre@gmail.com",
//        "userID": "38713cd3-7392-42b3-bede-2ddefd2689f6",

        val json = """{
                                      "responseData": {
                                        "userID": "",
                                        "fullName": "",
                                        "email": "",
                                        "contactNumber": "8790274613"
                                      },
                                      "success": true,
                                      "errorMessages": ""
                                    }"""

        // Create a Gson instance
        val gson = Gson()

        val verifyOtpResponse = gson.fromJson(json, VerifyOtpResponse::class.java)

        sharedViewModel.setUserData(verifyOtpResponse.responseData)
        // Prepare the message with user details
//        val message = "OTP Verified Successfully\nUserID: ${verifyOtpResponse.responseData.userID}\nFull Name: ${verifyOtpResponse.responseData.fullName}\nEmail: ${verifyOtpResponse.responseData.email}"
        val message = "OTP Verified Successfully"

        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
//        findNavController().navigate(R.id.action_OtpVerificationFragment_to_HomeFragment)

        findNavController().navigate(R.id.action_OtpVerificationFragment_to_HomeFragment, bundleOf("isNewUser" to true))

        sharedViewModel.setEditButtonsVisibility(false)
    }
    private fun sendOtpAPICall() {
        val otpInput = otpFields.joinToString(separator = "") { it.text.toString() }
        val countryCode = "+91"
        val mobileNumber1 = txt_phone_num.text.toString()

        val otpVerifyOtpRequest = VerifyOtpRequest(countryCode, mobileNumber1, otpInput)

        otpVerificationViewModel.verifyOtp2(otpVerifyOtpRequest).observe(viewLifecycleOwner) { result ->
            when (result) {
                is ApiResult.Success<VerifyOtpResponse> -> {
                    Toast.makeText(requireContext(), "welcome " + result.data.responseData.fullName , Toast.LENGTH_LONG).show()
                    // OTP sent successfully, handle success scenario

                    sharedViewModel.setUserData(result.data.responseData)

                    findNavController().navigate(R.id.action_OtpVerificationFragment_to_DashFragment)
                }
                is ApiResult.Error -> {
                    if (result.exception is HttpException) {
                        when (result.exception.code()) {
                            404 -> {
                                val userData = UserData("","","",mobileNumber1,false)
                                sharedViewModel.setUserData(userData)
                                sharedViewModel.setEditButtonsVisibility(true)
                                findNavController().navigate(R.id.action_OtpVerificationFragment_to_HomeFragment, bundleOf("isNewUser" to true))
                            }
                            200 -> {
                                val message = "OTP Verified Successfully"
                                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                                findNavController().navigate(R.id.action_OtpVerificationFragment_to_HomeFragment)
                                sharedViewModel.setEditButtonsVisibility(false)
                            }
                            else -> {
                                // For other errors, show error message
                                Toast.makeText(context, "OTP Verification Failed, please try again... ", Toast.LENGTH_LONG).show()
                            }
                        }
                    } else {
                        // Handle non-HttpException related errors
                        Toast.makeText(context, "An unexpected error occurred, please try again...", Toast.LENGTH_LONG).show()
                    }
                }
                is ApiResult.Loading -> {
                    // Show loading indicator
                }
            }
        }
    }



    private fun setupOtpFields() {
        otpFields.forEachIndexed { index, editText ->
            editText.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    if (count == 1 && index < otpFields.size - 1) {
                        otpFields[index + 1].requestFocus()
                    }
                    if (before == 1 && index > 0) {
                        otpFields[index - 1].requestFocus()
                    }
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
    }


    override fun onResume() {
        super.onResume()
        continueOtpCountdownTimer()
    }


    private fun startOtpCountdownTimer() {
        // Assuming 120000 milliseconds (2 minutes) as the duration
        val duration = 120000L
        val endTime = System.currentTimeMillis() + duration
        with(PreferenceManager.getDefaultSharedPreferences(context).edit()) {
            putLong("OTP_TIMER_END_TIME", endTime)
            apply()
        }

        continueOtpCountdownTimer()
    }

    private fun continueOtpCountdownTimer() {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        val endTime = sharedPreferences.getLong("OTP_TIMER_END_TIME", 0L)
        val currentTime = System.currentTimeMillis()
        val timeLeft = endTime - currentTime

        if (timeLeft > 0) {
            countDownTimer?.cancel()
            countDownTimer = object : CountDownTimer(timeLeft, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    if (isAdded) { // Check if fragment is currently added to its activity
                        txtTimer.text = getString(R.string.otp_message) + getString(R.string.timer_format, millisUntilFinished / 60000, (millisUntilFinished % 60000) / 1000)
                        otpNotificationTxt.visibility = View.GONE // Ensure message is hidden during countdown
                        txtResend.isEnabled = false // Ensure resend button is disabled during countdown
                    }
                }

                override fun onFinish() {
                    if (isAdded) {
                        otpNotificationTxt.visibility = View.VISIBLE // Show OTP expired message
                        otpNotificationTxt.text = getString(R.string.timer_expired)
                        txtResend.isEnabled = true // Enable resend button
                        updateResendButtonAppearance(true)
                    }
                }
            }.start()
        } else {
            otpNotificationTxt.visibility = View.VISIBLE
            otpNotificationTxt.text = getString(R.string.timer_expired)
            txtTimer.visibility = View.GONE
            txtResend.isEnabled = true // Enable resend button immediately if timer already expired
        }
    }

    private fun setupResendButton() {
        txtResend.setOnClickListener {
            // Your logic to resend the OTP
            startOtpCountdownTimer() // Restart the timer when OTP is resent
            updateResendButtonAppearance(false)
            sendOtp()
        }
    }

    override fun onPause() {
        super.onPause()
        countDownTimer?.cancel()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        countDownTimer?.cancel()
    }


}
