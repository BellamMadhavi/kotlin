package com.motivitylabs.bustrackingapp.model.response

import com.motivitylabs.bustrackingapp.ui.home.PreferenceFinal

data class PreferenceResponse(
    val responseData: List<PreferenceFinal>,
    val success: Boolean,
    val errorMessages: String?
)