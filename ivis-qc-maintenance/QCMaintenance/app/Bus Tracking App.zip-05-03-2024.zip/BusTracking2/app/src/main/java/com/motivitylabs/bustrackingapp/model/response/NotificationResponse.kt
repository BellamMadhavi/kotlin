package com.motivitylabs.bustrackingapp.model.response

class NotificationResponse(val responseData: String,
                            val success: Boolean,
                            val errorMessages: String?)

