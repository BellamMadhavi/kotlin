package com.motivitylabs.bustrackingapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.liveData
import com.motivitylabs.bustrackingapp.model.request.RegisterRequest
import com.motivitylabs.bustrackingapp.model.request.UpdateProfileRequest
import com.motivitylabs.bustrackingapp.network.RetrofitInstance.apiService
import com.motivitylabs.bustrackingapp.repository.UserRepository
import com.motivitylabs.bustrackingapp.util.ApiResult

class RegisterViewModel(private val userRepository: UserRepository) : ViewModel() {
    fun registerUser(request: RegisterRequest) = liveData {
        emit(ApiResult.Loading)
        val result = userRepository.registerUser(request)
        emit(result)
    }

    fun updateProfile(request: UpdateProfileRequest) = liveData {
        emit(ApiResult.Loading)
        val result = userRepository.updateProfile(request)
        emit(result)
    }
    // Add more functions to handle other API calls similarly
}
