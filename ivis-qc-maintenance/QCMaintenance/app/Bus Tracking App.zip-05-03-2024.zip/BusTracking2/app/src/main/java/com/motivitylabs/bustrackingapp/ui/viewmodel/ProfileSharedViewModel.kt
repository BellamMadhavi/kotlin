package com.motivitylabs.bustrackingapp.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.motivitylabs.bustrackingapp.model.response.UserData

class ProfileSharedViewModel : ViewModel() {
    private val _editButtonsVisibility = MutableLiveData<Boolean>()
    val editButtonsVisibility: LiveData<Boolean>
        get() = _editButtonsVisibility
    private val _userData = MutableLiveData<UserData?>()
    val userData: LiveData<UserData?> = _userData

    // Method to set user data
    fun setUserData(data: UserData?) {
        _userData.value = data
    }

    // Method to directly get user data
    fun getUserData(): UserData? {
        return _userData.value
    }

    fun setEditButtonsVisibility(visible: Boolean) {
        _editButtonsVisibility.value = visible
    }

}
