package com.motivitylabs.bustrackingapp.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.motivitylabs.bustrackingapp.R
import androidx.navigation.ui.setupWithNavController

class NavigationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_navigation)

        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottom_navigation_view)
        val navController = findNavController(R.id.naxvFragment) // Ensure the ID matches your NavHostFragment's ID

        // Set up BottomNavigationView with NavController
        bottomNavigationView.setupWithNavController(navController)
        bottomNavigationView.itemIconTintList = null
        // Listen for navigation changes to show/hide BottomNavigationView
        navController.addOnDestinationChangedListener { _, destination, _ ->
            when (destination.id) {
                R.id.MainScreenFragment, R.id.LoginFragment, R.id.OtpverficationFragment, R.id.AddPreferencesFragment -> bottomNavigationView.visibility = View.GONE
                else -> bottomNavigationView.visibility = View.VISIBLE
            }
        }
    }
}
